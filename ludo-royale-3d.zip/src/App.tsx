/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { GameScene } from './three/GameScene';
import { GameEngine, GameEngineState } from './game/GameEngine';
import {
  PlayerColor,
  PlayerConfig,
  GameSettings,
  AIDifficulty,
  CameraViewMode,
} from './game/types';
import { audioManager } from './audio/AudioManager';
import { profileManager } from './game/ProfileManager';
import { MainMenu } from './components/MainMenu';
import { GameHUD, KillBannerData } from './components/GameHUD';
import { VictoryModal } from './components/VictoryModal';
import { SettingsModal } from './components/SettingsModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { ProfileModal } from './components/ProfileModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { OnlineRoomModal } from './components/OnlineRoomModal';

export default function App() {
  // Screens: 'menu' | 'playing'
  const [screen, setScreen] = useState<'menu' | 'playing'>('menu');

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isOnlineModalOpen, setIsOnlineModalOpen] = useState(false);

  // Settings State
  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem('ludo_royale_settings_v1');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      soundVolume: 0.8,
      musicVolume: 0.35,
      isMuted: false,
      graphicsQuality: 'high',
      reducedMotion: false,
      cameraSensitivity: 1.0,
      allowCameraRotation: true,
      extraTurnOnSix: true,
      threeSixesPenalty: true,
      captureBonusTurn: true,
      homeBonusTurn: true,
      quickMode: false,
      animationSpeed: 1.0,
    };
  });

  // Active Match
  const [currentMatchMode, setCurrentMatchMode] = useState<'vs_ai' | 'local' | 'online'>('vs_ai');
  const [activePlayers, setActivePlayers] = useState<PlayerConfig[]>([]);
  const [matchStartTime, setMatchStartTime] = useState<number>(0);
  const [killBanner, setKillBanner] = useState<KillBannerData | null>(null);

  // Engine State
  const [engineState, setEngineState] = useState<GameEngineState | null>(null);

  // Three.js Canvas container ref
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<GameScene | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Synchronize audio settings
  useEffect(() => {
    audioManager.setVolumes(settings.soundVolume, settings.musicVolume, settings.isMuted);
    localStorage.setItem('ludo_royale_settings_v1', JSON.stringify(settings));
  }, [settings]);

  const handleTokenHover = (color: PlayerColor | null, id: number | null) => {
    if (!sceneRef.current || !engineRef.current) return;
    if (color === null || id === null) {
      sceneRef.current.effects.hidePathPreview();
      return;
    }
    const move = engineRef.current.state.legalMoves.find((m) => m.tokenId === id);
    if (move) {
      sceneRef.current.effects.showPathPreview(color, move.fromStep, move.toStep, move.willCapture);
    } else {
      sceneRef.current.effects.hidePathPreview();
    }
  };

  // Initialize or reconfigure 3D scene when entering 'playing' screen
  useEffect(() => {
    if (screen !== 'playing') {
      if (sceneRef.current) {
        sceneRef.current.dispose();
        sceneRef.current = null;
      }
      if (engineRef.current) {
        engineRef.current.dispose();
        engineRef.current = null;
      }
      return;
    }

    if (!canvasMountRef.current) return;

    // Start background lounge music on user game interaction
    if (!settings.isMuted) {
      audioManager.startBackgroundMusic();
    }

    // 1. Create Engine
    const engine = new GameEngine(activePlayers, settings);
    engineRef.current = engine;

    // 2. Create 3D Scene
    const scene = new GameScene(canvasMountRef.current, {
      onTokenClicked: (color, id) => {
        audioManager.playButtonClick();
        scene.effects.hidePathPreview();
        engine.selectTokenAndMove(id);
      },
      onDiceClicked: () => {
        audioManager.playButtonClick();
        engine.rollDice();
      },
      onDiceRollComplete: () => {
        // Handled in engine
      },
      onDiceBounce: () => {
        audioManager.playDiceSettle();
      },
      onTokenHop: (step) => {
        audioManager.playTokenHop();
        // Safe square star chime if landing on safe star
        if (step === 8 || step === 21 || step === 34 || step === 47) {
          audioManager.playStarSafeChime();
        }
      },
      onTokenHover: (color, id) => {
        handleTokenHover(color, id);
      },
    });
    sceneRef.current = scene;

    scene.allowManualRotation = settings.allowCameraRotation;

    // 3. Connect Engine Callbacks to Scene & Audio
    engine.onPerformDiceRoll = (targetResult, playerColor, onComplete) => {
      audioManager.playDiceRoll();
      scene.rollDice(targetResult, playerColor, () => {
        onComplete();
      });
    };

    engine.onPerformTokenMove = (color, tokenId, fromStep, toStep, speedMult, onComplete) => {
      scene.effects.hidePathPreview();
      scene.animateTokenMove(color, tokenId, fromStep, toStep, speedMult, () => {
        onComplete();
      });
    };

    engine.onPerformCapture = (
      victimColor,
      victimTokenId,
      attackerColor,
      attackerTokenId,
      onComplete
    ) => {
      const attacker = activePlayers.find((p) => p.color === attackerColor);
      setKillBanner({
        active: true,
        attackerColor,
        victimColor,
        attackerName: attacker?.name || attackerColor.toUpperCase(),
      });
      setTimeout(() => setKillBanner(null), 2400);

      scene.animateTokenCapture(
        victimColor,
        victimTokenId,
        attackerColor,
        attackerTokenId,
        () => {
          onComplete();
        }
      );
    };

    engine.onVictory = (winner) => {
      audioManager.playVictoryFanfare();
      const durationSec = Math.round((Date.now() - matchStartTime) / 1000);
      profileManager.recordMatchEnd(
        winner.type === 'human',
        currentMatchMode,
        winner.name,
        winner.color,
        durationSec
      );
    };

    engine.onGameStatsUpdate = (delta) => {
      profileManager.recordDelta(delta.captures, delta.sixes);
    };

    // 4. Subscribe React state to engine
    const unsubscribe = engine.subscribe((st) => {
      setEngineState(st);

      // Highlight selectable tokens on 3D board
      const activeP = st.players[st.activePlayerIndex];
      if (st.phase === 'waiting_for_move' && activeP.type === 'human') {
        const selectable = st.legalMoves.map((m) => ({ color: activeP.color, id: m.tokenId }));
        scene.setSelectableTokens(selectable);
      } else {
        scene.setSelectableTokens([]);
      }

      // Sync positions when not moving
      if (st.phase === 'idle' || st.phase === 'resolving') {
        scene.syncTokenStates(st.tokens);
      }
    });

    // 5. Start Match
    engine.startMatch();

    return () => {
      unsubscribe();
      scene.dispose();
      sceneRef.current = null;
      engine.dispose();
      engineRef.current = null;
    };
  }, [screen, activePlayers]);

  // Mode Launch Handlers
  const handleStartVsAI = (playerColor: PlayerColor, difficulty: AIDifficulty, playerCount: 2 | 4) => {
    audioManager.playButtonClick();
    const profile = profileManager.getProfile();

    const humanPlayer: PlayerConfig = {
      id: 'human_player_1',
      name: profile.name,
      color: playerColor,
      type: 'human',
      avatar: profile.avatar,
    };

    const colors: PlayerColor[] = ['red', 'blue', 'yellow', 'green'];
    const aiColors = colors.filter((c) => c !== playerColor);

    const botNames = ['Lord Sterling (AI)', 'Duchess Zara (AI)', 'Baron Von Dice (AI)'];
    const botAvatars = ['🤖', '⚔️', '🦁'];

    const neededBots = playerCount - 1;
    const aiPlayers: PlayerConfig[] = [];

    for (let i = 0; i < neededBots; i++) {
      aiPlayers.push({
        id: `ai_bot_${i}`,
        name: botNames[i % botNames.length],
        color: aiColors[i],
        type: 'ai',
        difficulty,
        avatar: botAvatars[i % botAvatars.length],
      });
    }

    const order: PlayerColor[] = ['red', 'blue', 'yellow', 'green'];
    const all = [humanPlayer, ...aiPlayers].sort(
      (a, b) => order.indexOf(a.color) - order.indexOf(b.color)
    );

    setCurrentMatchMode('vs_ai');
    setActivePlayers(all);
    setMatchStartTime(Date.now());
    setScreen('playing');
  };

  const handleStartLocalMultiplayer = (players: PlayerConfig[]) => {
    audioManager.playButtonClick();
    setCurrentMatchMode('local');
    setActivePlayers(players);
    setMatchStartTime(Date.now());
    setScreen('playing');
  };

  const handleStartOnlineMatch = (players: PlayerConfig[]) => {
    audioManager.playButtonClick();
    setCurrentMatchMode('online');
    setActivePlayers(players);
    setMatchStartTime(Date.now());
    setScreen('playing');
  };

  const handleExitMatch = () => {
    audioManager.playButtonClick();
    audioManager.stopBackgroundMusic();
    setScreen('menu');
  };

  const handleRematch = () => {
    audioManager.playButtonClick();
    if (engineRef.current) {
      engineRef.current.startMatch();
      setMatchStartTime(Date.now());
    }
  };

  const handleToggleMute = () => {
    const nextMuted = !settings.isMuted;
    setSettings((s) => ({ ...s, isMuted: nextMuted }));
    if (nextMuted) {
      audioManager.stopBackgroundMusic();
    } else {
      audioManager.startBackgroundMusic();
    }
  };

  return (
    <div className="relative w-screen h-screen bg-neutral-950 overflow-hidden font-sans select-none">
      {screen === 'menu' ? (
        <MainMenu
          onStartVsAI={handleStartVsAI}
          onStartLocalMultiplayer={handleStartLocalMultiplayer}
          onOpenOnlineLobby={() => {
            audioManager.playButtonClick();
            setIsOnlineModalOpen(true);
          }}
          onOpenHowToPlay={() => {
            audioManager.playButtonClick();
            setIsHowToPlayOpen(true);
          }}
          onOpenLeaderboard={() => {
            audioManager.playButtonClick();
            setIsLeaderboardOpen(true);
          }}
          onOpenProfile={() => {
            audioManager.playButtonClick();
            setIsProfileOpen(true);
          }}
          onOpenSettings={() => {
            audioManager.playButtonClick();
            setIsSettingsOpen(true);
          }}
        />
      ) : (
        <div className="relative w-full h-full">
          {/* Stable WebGL Canvas Mount Container */}
          <div ref={canvasMountRef} className="absolute inset-0 w-full h-full" />

          {/* Interactive UI Overlay & Collapsible Bottom Dock */}
          {engineState && (
            <GameHUD
              gameState={engineState}
              settings={settings}
              killBanner={killBanner}
              onRollDice={() => {
                audioManager.playButtonClick();
                engineRef.current?.rollDice();
              }}
              onSelectToken={(tokenId) => {
                audioManager.playButtonClick();
                engineRef.current?.selectTokenAndMove(tokenId);
              }}
              onHoverToken={(tokenId) => {
                const activeColor = engineState.players[engineState.activePlayerIndex]?.color;
                handleTokenHover(tokenId !== null ? activeColor : null, tokenId);
              }}
              onChangeCamera={(camMode) => {
                audioManager.playButtonClick();
                sceneRef.current?.setCameraPreset(
                  camMode,
                  engineState.players[engineState.activePlayerIndex]?.color
                );
              }}
              onOpenSettings={() => {
                audioManager.playButtonClick();
                setIsSettingsOpen(true);
              }}
              onOpenHelp={() => {
                audioManager.playButtonClick();
                setIsHowToPlayOpen(true);
              }}
              onExitMatch={handleExitMatch}
              onToggleMute={handleToggleMute}
            />
          )}

          {/* Victory Modal */}
          {engineState?.winner && (
            <VictoryModal
              winner={engineState.winner}
              onRematch={handleRematch}
              onHome={handleExitMatch}
            />
          )}
        </div>
      )}

      {/* Global Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSt) => {
          setSettings(newSt);
          engineRef.current?.updateSettings(newSt);
          if (sceneRef.current) {
            sceneRef.current.allowManualRotation = newSt.allowCameraRotation;
          }
        }}
      />

      <HowToPlayModal
        isOpen={isHowToPlayOpen}
        onClose={() => setIsHowToPlayOpen(false)}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
      />

      <LeaderboardModal
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
      />

      <OnlineRoomModal
        isOpen={isOnlineModalOpen}
        onClose={() => setIsOnlineModalOpen(false)}
        onStartOnlineMatch={handleStartOnlineMatch}
      />
    </div>
  );
}
