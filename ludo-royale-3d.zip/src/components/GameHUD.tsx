/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Volume2,
  VolumeX,
  Sliders,
  LogOut,
  Camera,
  RotateCcw,
  Eye,
  Shield,
  HelpCircle,
  Swords,
  Flame,
  Smile,
} from 'lucide-react';
import { GameEngineState } from '../game/GameEngine';
import { CameraViewMode, GameSettings, PlayerColor } from '../game/types';
import { PLAYER_HEX_COLORS } from '../three/Materials';

export interface KillBannerData {
  active: boolean;
  attackerColor: PlayerColor;
  victimColor: PlayerColor;
  attackerName: string;
}

interface GameHUDProps {
  gameState: GameEngineState;
  settings: GameSettings;
  killBanner: KillBannerData | null;
  onRollDice: () => void;
  onSelectToken: (tokenId: number) => void;
  onHoverToken: (tokenId: number | null) => void;
  onChangeCamera: (mode: CameraViewMode) => void;
  onOpenSettings: () => void;
  onOpenHelp: () => void;
  onExitMatch: () => void;
  onToggleMute: () => void;
}

const EMOTE_LIST = ['👑', '⚔️', '🔥', '🎲', '🛡️', '⚡'];

export const GameHUD: React.FC<GameHUDProps> = ({
  gameState,
  settings,
  killBanner,
  onRollDice,
  onSelectToken,
  onHoverToken,
  onChangeCamera,
  onOpenSettings,
  onOpenHelp,
  onExitMatch,
  onToggleMute,
}) => {
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [activeCam, setActiveCam] = useState<CameraViewMode>('isometric');
  const [activeEmote, setActiveEmote] = useState<string | null>(null);
  const [isEmotePickerOpen, setIsEmotePickerOpen] = useState(false);

  const activePlayer = gameState.players[gameState.activePlayerIndex];
  const isHumanTurn = activePlayer?.type === 'human';
  const isRolling = gameState.phase === 'rolling';
  const isWaitingMove = gameState.phase === 'waiting_for_move';
  const canRoll = isHumanTurn && gameState.phase === 'idle';

  const hexColor = activePlayer ? PLAYER_HEX_COLORS[activePlayer.color] : '#e53935';

  const handleCamChange = (mode: CameraViewMode) => {
    setActiveCam(mode);
    onChangeCamera(mode);
  };

  const handleTriggerEmote = (em: string) => {
    setActiveEmote(em);
    setIsEmotePickerOpen(false);
    setTimeout(() => setActiveEmote(null), 2500);
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 sm:p-5 select-none overflow-hidden">
      {/* Top Header Cluster */}
      <div className="flex items-center justify-between w-full pointer-events-auto">
        {/* Left: Minimal Title / Spec Badge */}
        <div className="flex items-center gap-3 bg-neutral-950/80 border border-neutral-800/80 px-4 py-2 rounded-2xl shadow-lg">
          <span className="text-xl">🎲</span>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Ludo Royale 3D
            </div>
            <div className="text-[11px] text-neutral-400 flex items-center gap-2">
              <span>Turn <strong className="text-white font-mono">{gameState.turnCount}</strong></span>
              <span>·</span>
              <span className="flex items-center gap-1 text-amber-300">
                <Swords size={12} /> Live Action
              </span>
            </div>
          </div>
        </div>

        {/* Center: Emote Bubble Popup if triggered */}
        {activeEmote && (
          <div className="animate-bounce bg-neutral-900/90 border border-amber-500/60 px-4 py-2 rounded-2xl text-2xl shadow-xl flex items-center gap-2">
            <span>{activeEmote}</span>
            <span className="text-xs text-neutral-300 font-semibold">{activePlayer?.name} reacted!</span>
          </div>
        )}

        {/* Right: Quick Tools */}
        <div className="flex items-center gap-2 bg-neutral-950/80 border border-neutral-800/80 p-1.5 rounded-2xl shadow-lg">
          <div className="relative">
            <button
              onClick={() => setIsEmotePickerOpen(!isEmotePickerOpen)}
              title="React with Emote"
              className="p-2 rounded-xl text-neutral-400 hover:text-amber-400 hover:bg-neutral-800 transition cursor-pointer"
            >
              <Smile size={18} />
            </button>

            {isEmotePickerOpen && (
              <div className="absolute right-0 top-12 bg-neutral-900 border border-neutral-700 p-2 rounded-2xl shadow-2xl flex gap-1 z-50">
                {EMOTE_LIST.map((em) => (
                  <button
                    key={em}
                    onClick={() => handleTriggerEmote(em)}
                    className="w-8 h-8 rounded-xl hover:bg-neutral-800 text-lg flex items-center justify-center transition cursor-pointer"
                  >
                    {em}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={onToggleMute}
            title={settings.isMuted ? 'Unmute Audio' : 'Mute Audio'}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer"
          >
            {settings.isMuted ? <VolumeX size={18} className="text-red-400" /> : <Volume2 size={18} />}
          </button>
          <button
            onClick={onOpenHelp}
            title="Rules & How to Play"
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer"
          >
            <HelpCircle size={18} />
          </button>
          <button
            onClick={onOpenSettings}
            title="Settings"
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer"
          >
            <Sliders size={18} />
          </button>
          <button
            onClick={onExitMatch}
            title="Exit to Main Menu"
            className="p-2 rounded-xl text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 transition cursor-pointer"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>

      {/* Cinematic Dramatic Kill / Knockout Banner Overlay */}
      {killBanner && killBanner.active && (
        <div className="self-center z-40 my-auto animate-in zoom-in-90 fade-in duration-200">
          <div className="bg-gradient-to-r from-red-600/90 via-amber-600/90 to-red-600/90 border-2 border-amber-300 text-white px-8 py-3.5 rounded-3xl shadow-2xl shadow-red-500/50 flex items-center gap-4">
            <span className="text-3xl animate-spin">⚔️</span>
            <div>
              <div className="text-base sm:text-lg font-black uppercase tracking-wider text-amber-200 drop-shadow-md">
                KNOCKOUT STRIKE!
              </div>
              <div className="text-xs text-neutral-100 font-semibold">
                <strong>{killBanner.attackerName}</strong> eliminated{' '}
                <strong className="uppercase">{killBanner.victimColor}</strong>'s piece! (Bonus Roll Awarded)
              </div>
            </div>
            <span className="text-3xl">💥</span>
          </div>
        </div>
      )}

      {/* Center 3D Viewport is 100% UNOBSTRUCTED */}
      <div className="flex-1" />

      {/* Unified Bottom Control Dock (Collapsible Cinema Mode) */}
      <div className="pointer-events-auto w-full flex flex-col items-center">
        {/* Collapse / Expand Toggle Tab */}
        <button
          onClick={() => setIsDockCollapsed(!isDockCollapsed)}
          className="mb-1.5 px-3 py-1 bg-neutral-950/80 border border-neutral-800 text-[11px] text-neutral-400 hover:text-white font-medium rounded-t-xl flex items-center gap-1 transition shadow-md cursor-pointer"
        >
          {isDockCollapsed ? (
            <>
              <ChevronUp size={14} /> Show Controls
            </>
          ) : (
            <>
              <ChevronDown size={14} /> Hide Dock (Zen View)
            </>
          )}
        </button>

        {/* The Dock Container - Low profile on smartphones so board is never covered */}
        <div
          className={`w-full max-w-4xl bg-neutral-950/95 border border-neutral-800/90 rounded-2xl sm:rounded-3xl p-2 sm:p-4 shadow-2xl transition-all duration-300 ${
            isDockCollapsed ? 'translate-y-full opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'
          }`}
        >
          {/* Status Message Banner */}
          <div className="mb-1.5 sm:mb-3 text-center">
            <div className="inline-flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-0.5 sm:py-1 rounded-full bg-neutral-900 border border-neutral-800 text-[11px] sm:text-xs text-neutral-200 shadow-inner">
              <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: hexColor }} />
              <span className="font-semibold truncate max-w-[280px] sm:max-w-none">{gameState.statusMessage}</span>
            </div>
          </div>

          <div className="flex flex-row items-center justify-between gap-1.5 sm:gap-6">
            {/* Left: Active Player Card */}
            <div className="flex items-center gap-2 sm:gap-3 bg-neutral-900/80 p-1.5 sm:p-2.5 rounded-xl sm:rounded-2xl border border-neutral-800/80 shrink-0">
              <div
                className="w-8 h-8 sm:w-11 sm:h-11 rounded-lg sm:rounded-xl flex items-center justify-center text-lg sm:text-2xl border-2 shadow-md shrink-0"
                style={{ borderColor: hexColor, backgroundColor: `${hexColor}20` }}
              >
                {activePlayer?.avatar}
              </div>
              <div className="hidden xs:block min-w-0 pr-1 sm:pr-2">
                <div className="text-xs sm:text-sm font-bold text-white truncate max-w-[90px] sm:max-w-none">
                  {activePlayer?.name}
                </div>
                <div className="flex items-center gap-1.5 text-[10px] sm:text-xs">
                  <span className="capitalize font-semibold" style={{ color: hexColor }}>
                    {activePlayer?.color}
                  </span>
                </div>
              </div>
            </div>

            {/* Center: Tactile Dice Roll Station */}
            <div className="flex-1 sm:flex-none flex items-center justify-center">
              <button
                disabled={!canRoll || isRolling}
                onClick={onRollDice}
                className={`relative w-full sm:w-auto px-4 sm:px-8 py-2.5 sm:py-3.5 rounded-xl sm:rounded-2xl font-black text-xs sm:text-sm uppercase tracking-wider transition shadow-xl flex items-center justify-center gap-2 sm:gap-3 cursor-pointer ${
                  canRoll
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 active:scale-98 shadow-amber-500/20'
                    : isRolling
                    ? 'bg-amber-600/50 text-neutral-900 cursor-not-allowed animate-pulse'
                    : 'bg-neutral-800 text-neutral-500 border border-neutral-700/50 cursor-not-allowed'
                }`}
              >
                <span className="text-xl sm:text-2xl">🎲</span>
                <span>{isRolling ? 'Rolling...' : 'Roll Dice'}</span>

                {gameState.diceRoll !== null && !isRolling && (
                  <span className="w-6 h-6 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-neutral-950 text-amber-400 border border-amber-400/40 flex items-center justify-center font-mono text-xs sm:text-base font-black shadow-inner shrink-0">
                    {gameState.diceRoll}
                  </span>
                )}
              </button>
            </div>

            {/* Right: Camera View Pills & Legal Tokens Selector */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 justify-end">
              {isWaitingMove && isHumanTurn && gameState.legalMoves.length > 0 ? (
                <div className="flex items-center gap-1 bg-neutral-900/80 p-1 sm:p-1.5 rounded-xl border border-amber-500/40">
                  <span className="hidden sm:inline text-[11px] font-bold text-amber-400 px-1">Move:</span>
                  {gameState.legalMoves.map((m) => (
                    <button
                      key={m.tokenId}
                      onMouseEnter={() => onHoverToken(m.tokenId)}
                      onMouseLeave={() => onHoverToken(null)}
                      onClick={() => onSelectToken(m.tokenId)}
                      className="px-2 py-1 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-[11px] sm:text-xs rounded-lg transition cursor-pointer shadow-xs"
                    >
                      #{m.tokenId + 1}
                      {m.willCapture && '⚔️'}
                      {m.willFinish && '👑'}
                    </button>
                  ))}
                </div>
              ) : (
                /* Camera Controls */
                <div className="flex items-center gap-1 bg-neutral-900/80 p-1 rounded-xl border border-neutral-800">
                  {[
                    { id: 'isometric' as CameraViewMode, label: '3D', full: '3D Angled' },
                    { id: 'topdown' as CameraViewMode, label: 'Top', full: 'Top-Down' },
                    { id: 'active_player' as CameraViewMode, label: 'POV', full: 'Active POV' },
                  ].map((cam) => (
                    <button
                      key={cam.id}
                      onClick={() => handleCamChange(cam.id)}
                      className={`px-2 sm:px-2.5 py-1 text-[11px] sm:text-xs rounded-lg font-medium transition cursor-pointer ${
                        activeCam === cam.id
                          ? 'bg-neutral-700 text-white shadow-xs'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      <span className="sm:hidden">{cam.label}</span>
                      <span className="hidden sm:inline">{cam.full}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
