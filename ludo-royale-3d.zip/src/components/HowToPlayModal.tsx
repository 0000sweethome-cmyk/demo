/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Shield, Award, RotateCcw, Zap } from 'lucide-react';

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-amber-600/40 rounded-2xl p-6 text-white shadow-2xl max-h-[88vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <span className="text-2xl">📜</span>
            <h2 className="text-xl font-bold tracking-wide text-amber-400">Rules & How to Play</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="mt-4 space-y-4 text-sm text-neutral-300">
          <div className="bg-neutral-800/60 p-4 rounded-xl border border-neutral-700/50">
            <h3 className="font-semibold text-white flex items-center gap-2 mb-2">
              <span className="text-amber-400 font-bold">1.</span> Objective of the Game
            </h3>
            <p>
              Navigate all 4 of your colored tokens from your starting yard around the board and into your
              central home triangle. In <strong>Quick Mode</strong>, you only need 2 tokens to claim victory!
            </p>
          </div>

          <div className="bg-neutral-800/60 p-4 rounded-xl border border-neutral-700/50">
            <h3 className="font-semibold text-white flex items-center gap-2 mb-2">
              <span className="text-amber-400 font-bold">2.</span> Leaving the Yard
            </h3>
            <p>
              Tokens start in their respective corner yard. You must roll a <strong>6</strong> on the 3D dice
              to bring a token out to your starting square. Rolling a 6 also grants an <strong>extra roll</strong>!
            </p>
          </div>

          <div className="bg-neutral-800/60 p-4 rounded-xl border border-neutral-700/50">
            <h3 className="font-semibold text-white flex items-center gap-2 mb-2">
              <Shield size={18} className="text-blue-400" />
              <span>3. Captures & Safe Squares</span>
            </h3>
            <p>
              If your token lands on an opponent's token on a regular track square, the opponent is 
              <strong> captured</strong> and returned to their home yard! Capturing also awards you a 
              <strong> bonus turn</strong>.
            </p>
            <p className="mt-2 text-neutral-400">
              ⭐ Squares marked with a <strong>Star</strong> or your color's <strong>Starting Square</strong> are
              <strong> Safe Havens</strong>. Tokens on safe squares cannot be captured, and multiple tokens can share them.
            </p>
          </div>

          <div className="bg-neutral-800/60 p-4 rounded-xl border border-neutral-700/50">
            <h3 className="font-semibold text-white flex items-center gap-2 mb-2">
              <Award size={18} className="text-emerald-400" />
              <span>4. Entering Home</span>
            </h3>
            <p>
              After completing the full circuit of 51 steps, your token enters your private colored home lane.
              You must roll the <strong>exact count</strong> required to land on the center victory triangle.
            </p>
          </div>

          <div className="bg-neutral-800/60 p-4 rounded-xl border border-neutral-700/50">
            <h3 className="font-semibold text-white flex items-center gap-2 mb-2">
              <Zap size={18} className="text-yellow-400" />
              <span>5. Three Consecutive Sixes Rule</span>
            </h3>
            <p>
              Rolling three 6s in a row forfeits the third roll's move to ensure fair play, passing the turn
              to the next player.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold rounded-xl transition cursor-pointer"
          >
            Got it, Let's Play!
          </button>
        </div>
      </div>
    </div>
  );
};
