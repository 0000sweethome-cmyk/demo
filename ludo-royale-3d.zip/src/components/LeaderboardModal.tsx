/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Trophy, History, Crown, Medal } from 'lucide-react';
import { profileManager } from '../game/ProfileManager';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({ isOpen, onClose }) => {
  const [tab, setTab] = useState<'leaderboard' | 'history'>('leaderboard');
  const stats = profileManager.getStats();
  const profile = profileManager.getProfile();
  const history = profileManager.getHistory();

  if (!isOpen) return null;

  // Curated Royale League leaderboard including user
  const leaderboardData = [
    { rank: 1, name: 'SultanOfDice', avatar: '🦁', wins: 48, winRate: '78%', xp: 4820 },
    { rank: 2, name: 'RoyalKnight', avatar: '⚔️', wins: 39, winRate: '71%', xp: 3950 },
    {
      rank: 3,
      name: `${profile.name} (You)`,
      avatar: profile.avatar,
      wins: stats.gamesWon,
      winRate: stats.gamesPlayed > 0 ? `${Math.round((stats.gamesWon / stats.gamesPlayed) * 100)}%` : '0%',
      xp: stats.totalXP,
      isCurrentUser: true,
    },
    { rank: 4, name: 'VanguardX', avatar: '🛡️', wins: 28, winRate: '64%', xp: 2840 },
    { rank: 5, name: 'DragonHeart', avatar: '🐉', wins: 22, winRate: '59%', xp: 2190 },
    { rank: 6, name: 'PhoenixClaw', avatar: '🦅', wins: 17, winRate: '52%', xp: 1740 },
  ].sort((a, b) => b.xp - a.xp).map((item, idx) => ({ ...item, rank: idx + 1 }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-amber-600/40 rounded-2xl p-6 text-white shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Trophy size={22} className="text-amber-400" />
            <h2 className="text-xl font-bold tracking-wide">Hall of Fame</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex gap-2 my-4 bg-neutral-800/80 p-1 rounded-xl">
          <button
            onClick={() => setTab('leaderboard')}
            className={`flex-1 py-2 rounded-lg font-semibold text-xs flex items-center justify-center gap-2 transition cursor-pointer ${
              tab === 'leaderboard'
                ? 'bg-amber-500 text-neutral-950 font-bold shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Crown size={15} /> League Leaderboard
          </button>
          <button
            onClick={() => setTab('history')}
            className={`flex-1 py-2 rounded-lg font-semibold text-xs flex items-center justify-center gap-2 transition cursor-pointer ${
              tab === 'history'
                ? 'bg-amber-500 text-neutral-950 font-bold shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <History size={15} /> Recent Matches
          </button>
        </div>

        {tab === 'leaderboard' ? (
          <div className="space-y-2">
            {leaderboardData.map((player) => (
              <div
                key={player.name}
                className={`p-3.5 rounded-xl border flex items-center justify-between transition ${
                  player.isCurrentUser
                    ? 'bg-amber-500/15 border-amber-500/70 shadow-sm'
                    : 'bg-neutral-800/50 border-neutral-700/40'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                      player.rank === 1
                        ? 'bg-amber-400 text-neutral-950'
                        : player.rank === 2
                        ? 'bg-neutral-300 text-neutral-950'
                        : player.rank === 3
                        ? 'bg-amber-700 text-white'
                        : 'bg-neutral-700 text-neutral-300'
                    }`}
                  >
                    {player.rank}
                  </span>
                  <span className="text-2xl">{player.avatar}</span>
                  <div>
                    <div className="font-semibold text-sm flex items-center gap-1.5">
                      <span>{player.name}</span>
                      {player.isCurrentUser && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-amber-500 text-neutral-950 font-bold">
                          YOU
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-neutral-400">
                      Wins: <span className="text-white font-medium">{player.wins}</span> · Win Rate:{' '}
                      <span className="text-emerald-400 font-medium">{player.winRate}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-bold text-amber-400 tabular-nums">{player.xp} XP</div>
                  <div className="text-[11px] text-neutral-400">Rank points</div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {history.length === 0 ? (
              <div className="text-center py-10 text-neutral-400 text-sm">
                No matches recorded yet. Play a match to build your legend!
              </div>
            ) : (
              history.map((match) => (
                <div
                  key={match.id}
                  className="p-3.5 bg-neutral-800/50 border border-neutral-700/40 rounded-xl flex items-center justify-between"
                >
                  <div>
                    <div className="text-sm font-semibold flex items-center gap-2">
                      <span className="capitalize text-amber-400">
                        {match.mode === 'vs_ai'
                          ? 'Vs Computer'
                          : match.mode === 'local'
                          ? 'Local Multiplayer'
                          : 'Online Match'}
                      </span>
                      <span className="text-xs text-neutral-400">· {match.date}</span>
                    </div>
                    <div className="text-xs text-neutral-300 mt-1">
                      Winner: <strong className="text-white">{match.winnerName}</strong> ({match.winnerColor})
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-xs px-2.5 py-1 rounded-lg font-bold ${
                        match.playerRank === 1
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                          : 'bg-neutral-700 text-neutral-300'
                      }`}
                    >
                      {match.playerRank === 1 ? '1st Place' : 'Finished'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold rounded-xl border border-neutral-700 transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
