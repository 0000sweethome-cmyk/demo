/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Play,
  Bot,
  Users,
  Globe,
  HelpCircle,
  Trophy,
  User,
  Sliders,
  Crown,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { PlayerColor, PlayerConfig, AIDifficulty } from '../game/types';
import { profileManager } from '../game/ProfileManager';

interface MainMenuProps {
  onStartVsAI: (color: PlayerColor, difficulty: AIDifficulty, playerCount: 2 | 4) => void;
  onStartLocalMultiplayer: (players: PlayerConfig[]) => void;
  onOpenOnlineLobby: () => void;
  onOpenHowToPlay: () => void;
  onOpenLeaderboard: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartVsAI,
  onStartLocalMultiplayer,
  onOpenOnlineLobby,
  onOpenHowToPlay,
  onOpenLeaderboard,
  onOpenProfile,
  onOpenSettings,
}) => {
  const [selectedTab, setSelectedTab] = useState<'main' | 'setup_ai' | 'setup_local'>('main');

  // AI Setup Options
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficulty>('medium');
  const [playerColor, setPlayerColor] = useState<PlayerColor>('red');
  const [aiPlayerCount, setAiPlayerCount] = useState<2 | 4>(4);

  // Local Multiplayer Setup
  const [localPlayerCount, setLocalPlayerCount] = useState<2 | 3 | 4>(4);
  const [localNames, setLocalNames] = useState<Record<PlayerColor, string>>({
    red: 'Player 1',
    blue: 'Player 2',
    yellow: 'Player 3',
    green: 'Player 4',
  });

  const profile = profileManager.getProfile();
  const stats = profileManager.getStats();

  const handleLaunchAI = () => {
    onStartVsAI(playerColor, aiDifficulty, aiPlayerCount);
  };

  const handleLaunchLocal = () => {
    const colors: PlayerColor[] =
      localPlayerCount === 2
        ? ['red', 'yellow']
        : localPlayerCount === 3
        ? ['red', 'blue', 'yellow']
        : ['red', 'blue', 'yellow', 'green'];

    const avatars = ['👑', '⚔️', '🛡️', '🦁'];

    const players: PlayerConfig[] = colors.map((col, idx) => ({
      id: `local_p_${idx}`,
      name: localNames[col] || `Player ${idx + 1}`,
      color: col,
      type: 'human',
      avatar: avatars[idx % avatars.length],
    }));

    onStartLocalMultiplayer(players);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between p-4 sm:p-8 bg-neutral-950 text-white overflow-x-hidden">
      {/* Background radial glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-amber-600/10 blur-[120px] pointer-events-none rounded-full" />

      {/* Top Bar */}
      <div className="relative z-10 flex items-center justify-between max-w-5xl mx-auto w-full">
        <button
          onClick={onOpenProfile}
          className="flex items-center gap-3 bg-neutral-900/80 hover:bg-neutral-800/80 border border-neutral-800 px-3.5 py-2 rounded-2xl transition cursor-pointer shadow-md"
        >
          <span className="text-2xl">{profile.avatar}</span>
          <div className="text-left">
            <div className="text-xs font-bold text-white">{profile.name}</div>
            <div className="text-[10px] text-amber-400 font-semibold">{stats.totalXP} XP</div>
          </div>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenLeaderboard}
            title="Leaderboard & Hall of Fame"
            className="p-2.5 bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 rounded-xl transition cursor-pointer"
          >
            <Trophy size={18} className="text-amber-400" />
          </button>
          <button
            onClick={onOpenHowToPlay}
            title="Rules & How to Play"
            className="p-2.5 bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 rounded-xl transition cursor-pointer"
          >
            <HelpCircle size={18} />
          </button>
          <button
            onClick={onOpenSettings}
            title="Settings"
            className="p-2.5 bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 rounded-xl transition cursor-pointer"
          >
            <Sliders size={18} />
          </button>
        </div>
      </div>

      {/* Main Center Content */}
      <div className="relative z-10 max-w-md w-full mx-auto my-auto py-6">
        {selectedTab === 'main' && (
          <div className="space-y-6 text-center animate-in fade-in duration-300">
            {/* Title Lockup */}
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
                <Crown size={14} /> The Grand Board Experience
              </div>
              <h1 className="text-4xl sm:text-5xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-white via-neutral-100 to-neutral-400 drop-shadow-md">
                LUDO ROYALE <span className="text-amber-400">3D</span>
              </h1>
              <p className="text-xs text-neutral-400 mt-2 max-w-xs mx-auto">
                Realistic 3D physical board, dynamic dice physics, tactical AI opponents, and competitive
                multiplayer.
              </p>
            </div>

            {/* Main Action CTAs */}
            <div className="space-y-3 pt-2">
              <button
                onClick={() => setSelectedTab('setup_ai')}
                className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-base uppercase tracking-wider rounded-2xl shadow-xl shadow-amber-500/20 transition flex items-center justify-center gap-3 cursor-pointer active:scale-98"
              >
                <Bot size={22} /> Play vs Computer
              </button>

              <button
                onClick={() => setSelectedTab('setup_local')}
                className="w-full py-3.5 bg-neutral-900/90 hover:bg-neutral-800 text-white font-bold text-sm tracking-wide rounded-2xl border border-neutral-700/80 transition flex items-center justify-center gap-3 cursor-pointer shadow-lg active:scale-98"
              >
                <Users size={20} className="text-blue-400" /> Pass & Play (Local Multiplayer)
              </button>

              <button
                onClick={onOpenOnlineLobby}
                className="w-full py-3.5 bg-neutral-900/90 hover:bg-neutral-800 text-white font-bold text-sm tracking-wide rounded-2xl border border-neutral-700/80 transition flex items-center justify-center gap-3 cursor-pointer shadow-lg active:scale-98"
              >
                <Globe size={20} className="text-emerald-400" /> Online Rooms & Friends
              </button>
            </div>
          </div>
        )}

        {/* AI Setup Mode */}
        {selectedTab === 'setup_ai' && (
          <div className="bg-neutral-900/90 border border-neutral-800 rounded-3xl p-6 shadow-2xl space-y-5 animate-in fade-in duration-300">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Bot size={20} className="text-amber-400" />
                <h2 className="font-bold text-base">Match vs Computer AI</h2>
              </div>
              <button
                onClick={() => setSelectedTab('main')}
                className="text-xs text-neutral-400 hover:text-white"
              >
                Back
              </button>
            </div>

            {/* Select Color */}
            <div>
              <label className="block text-xs uppercase font-semibold text-neutral-400 mb-2">
                Choose Your House Color
              </label>
              <div className="grid grid-cols-4 gap-2">
                {(['red', 'blue', 'yellow', 'green'] as PlayerColor[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => setPlayerColor(c)}
                    className={`py-2 rounded-xl text-xs font-bold uppercase tracking-wider border transition cursor-pointer ${
                      playerColor === c
                        ? 'border-white bg-white/10 shadow-sm'
                        : 'border-neutral-800 bg-neutral-800/40 hover:bg-neutral-800'
                    }`}
                  >
                    <span
                      className="inline-block w-2.5 h-2.5 rounded-full mr-1"
                      style={{
                        backgroundColor:
                          c === 'red'
                            ? '#e53935'
                            : c === 'blue'
                            ? '#1e88e5'
                            : c === 'yellow'
                            ? '#fbc02d'
                            : '#43a047',
                      }}
                    />
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Select AI Difficulty */}
            <div>
              <label className="block text-xs uppercase font-semibold text-neutral-400 mb-2">
                AI Difficulty Level
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { id: 'easy' as AIDifficulty, label: 'Easy' },
                  { id: 'medium' as AIDifficulty, label: 'Medium' },
                  { id: 'hard' as AIDifficulty, label: 'Hard' },
                  { id: 'expert' as AIDifficulty, label: 'Expert' },
                ].map((d) => (
                  <button
                    key={d.id}
                    onClick={() => setAiDifficulty(d.id)}
                    className={`py-2 rounded-xl text-xs font-bold transition cursor-pointer border ${
                      aiDifficulty === d.id
                        ? 'bg-amber-500 border-amber-400 text-neutral-950 shadow-xs'
                        : 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Select Player Count */}
            <div>
              <label className="block text-xs uppercase font-semibold text-neutral-400 mb-2">
                Total Players on Board
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { count: 2 as const, label: '2 Players (1v1 Duel)' },
                  { count: 4 as const, label: '4 Players (Full Royale)' },
                ].map((opt) => (
                  <button
                    key={opt.count}
                    onClick={() => setAiPlayerCount(opt.count)}
                    className={`py-2.5 text-xs font-bold rounded-xl border transition cursor-pointer ${
                      aiPlayerCount === opt.count
                        ? 'bg-neutral-700 border-amber-400 text-white'
                        : 'bg-neutral-800 border-neutral-700 text-neutral-400 hover:bg-neutral-750'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleLaunchAI}
              className="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-sm uppercase tracking-wider rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <Play size={18} /> Start 3D Game
            </button>
          </div>
        )}

        {/* Local Multiplayer Setup */}
        {selectedTab === 'setup_local' && (
          <div className="bg-neutral-900/90 border border-neutral-800 rounded-3xl p-6 shadow-2xl space-y-5 animate-in fade-in duration-300">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Users size={20} className="text-amber-400" />
                <h2 className="font-bold text-base">Pass & Play Setup</h2>
              </div>
              <button
                onClick={() => setSelectedTab('main')}
                className="text-xs text-neutral-400 hover:text-white"
              >
                Back
              </button>
            </div>

            {/* Player Count */}
            <div>
              <label className="block text-xs uppercase font-semibold text-neutral-400 mb-2">
                Number of Players
              </label>
              <div className="grid grid-cols-3 gap-2">
                {([2, 3, 4] as const).map((cnt) => (
                  <button
                    key={cnt}
                    onClick={() => setLocalPlayerCount(cnt)}
                    className={`py-2 text-xs font-bold rounded-xl border transition cursor-pointer ${
                      localPlayerCount === cnt
                        ? 'bg-amber-500 border-amber-400 text-neutral-950 shadow-xs'
                        : 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                    }`}
                  >
                    {cnt} Players
                  </button>
                ))}
              </div>
            </div>

            {/* Names Input */}
            <div className="space-y-2">
              <label className="block text-xs uppercase font-semibold text-neutral-400">
                Player Names
              </label>
              {(localPlayerCount === 2
                ? (['red', 'yellow'] as PlayerColor[])
                : localPlayerCount === 3
                ? (['red', 'blue', 'yellow'] as PlayerColor[])
                : (['red', 'blue', 'yellow', 'green'] as PlayerColor[])
              ).map((c, i) => (
                <div key={c} className="flex items-center gap-2">
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0"
                    style={{
                      backgroundColor:
                        c === 'red'
                          ? '#e53935'
                          : c === 'blue'
                          ? '#1e88e5'
                          : c === 'yellow'
                          ? '#fbc02d'
                          : '#43a047',
                    }}
                  />
                  <input
                    type="text"
                    value={localNames[c]}
                    onChange={(e) =>
                      setLocalNames({ ...localNames, [c]: e.target.value })
                    }
                    placeholder={`Player ${i + 1}`}
                    maxLength={14}
                    className="flex-1 bg-neutral-800/80 border border-neutral-700 px-3 py-1.5 rounded-lg text-xs font-semibold focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              ))}
            </div>

            <button
              onClick={handleLaunchLocal}
              className="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-sm uppercase tracking-wider rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <Play size={18} /> Launch Pass & Play
            </button>
          </div>
        )}
      </div>

      {/* Control Hint Line (Anti-AI Slop & Pure Game Craft Standard) */}
      <div className="relative z-10 max-w-5xl mx-auto w-full text-center text-[11px] text-neutral-500">
        Mouse Drag Rotate · Wheel Zoom · Tap Tokens to Move · Esc Pause
      </div>
    </div>
  );
};
