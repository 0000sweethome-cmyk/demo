/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Users, Copy, Check, Play, Globe, ShieldAlert } from 'lucide-react';
import { roomManager, RoomState } from '../multiplayer/RoomManager';
import { PlayerColor, PlayerConfig } from '../game/types';
import { profileManager } from '../game/ProfileManager';

interface OnlineRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartOnlineMatch: (players: PlayerConfig[]) => void;
}

export const OnlineRoomModal: React.FC<OnlineRoomModalProps> = ({
  isOpen,
  onClose,
  onStartOnlineMatch,
}) => {
  const [view, setView] = useState<'lobby' | 'in_room'>('lobby');
  const [joinCode, setJoinCode] = useState('');
  const [roomState, setRoomState] = useState<RoomState | null>(null);
  const [copied, setCopied] = useState(false);
  const [selectedColor, setSelectedColor] = useState<PlayerColor>('red');

  if (!isOpen) return null;

  const profile = profileManager.getProfile();

  const handleCreateRoom = () => {
    const room = roomManager.createRoom(profile.name, selectedColor);
    setRoomState({ ...room });
    setView('in_room');

    roomManager.onMessage((msg) => {
      if (roomManager.currentRoom) {
        setRoomState({ ...roomManager.currentRoom });
      }
      if (msg.type === 'START' && msg.payload.room) {
        onStartOnlineMatch(msg.payload.room.players);
        onClose();
      }
    });
  };

  const handleJoinRoom = () => {
    if (!joinCode.trim()) return;
    const ok = roomManager.joinRoom(joinCode.trim(), profile.name, selectedColor);
    if (ok && roomManager.currentRoom) {
      setRoomState({ ...roomManager.currentRoom });
      setView('in_room');

      roomManager.onMessage((msg) => {
        if (roomManager.currentRoom) {
          setRoomState({ ...roomManager.currentRoom });
        }
        if (msg.type === 'START' && msg.payload.room) {
          onStartOnlineMatch(msg.payload.room.players);
          onClose();
        }
      });
    }
  };

  const handleCopyCode = () => {
    if (roomState?.roomId) {
      navigator.clipboard.writeText(roomState.roomId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleLaunchMatch = () => {
    if (!roomState) return;

    // Fill remaining slots with AI or start with present players
    const currentCount = roomState.players.length;
    const finalPlayers: PlayerConfig[] = [...roomState.players];

    const colors: PlayerColor[] = ['red', 'blue', 'yellow', 'green'];
    const usedColors = finalPlayers.map((p) => p.color);

    if (currentCount < 2) {
      // Add a rival bot
      const remainingColor = colors.find((c) => !usedColors.includes(c)) || 'blue';
      finalPlayers.push({
        id: 'bot_online_rival',
        name: 'Baron Bot (AI)',
        color: remainingColor,
        type: 'ai',
        difficulty: 'hard',
        avatar: '🤖',
      });
    }

    roomManager.sendMessage({
      type: 'START',
      senderId: roomManager.myPlayerId,
      senderName: profile.name,
      roomId: roomState.roomId,
      payload: { room: { ...roomState, players: finalPlayers, isStarted: true } },
      timestamp: Date.now(),
    });

    onStartOnlineMatch(finalPlayers);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-xl bg-neutral-900 border border-amber-600/40 rounded-2xl p-6 text-white shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Globe size={22} className="text-amber-400" />
            <h2 className="text-xl font-bold tracking-wide">Online Multiplayer Lounge</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Informative Firebase status notice */}
        <div className="mt-4 p-3 bg-blue-950/40 border border-blue-500/30 rounded-xl text-xs text-blue-200 flex items-start gap-2.5">
          <ShieldAlert size={18} className="text-blue-400 shrink-0 mt-0.5" />
          <div>
            <strong>Peer & Local Sync Active:</strong> Rooms utilize low-latency cross-tab & local socket
            channels. If cloud database is provisioned, rooms automatically sync globally across separate
            networks.
          </div>
        </div>

        {view === 'lobby' ? (
          <div className="mt-5 space-y-6">
            {/* Color Preference */}
            <div>
              <label className="block text-xs uppercase font-semibold text-neutral-400 mb-2">
                Select Your House Color
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { color: 'red' as PlayerColor, label: 'Red' },
                  { color: 'blue' as PlayerColor, label: 'Blue' },
                  { color: 'yellow' as PlayerColor, label: 'Yellow' },
                  { color: 'green' as PlayerColor, label: 'Green' },
                ].map((item) => (
                  <button
                    key={item.color}
                    onClick={() => setSelectedColor(item.color)}
                    className={`py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider border transition cursor-pointer ${
                      selectedColor === item.color
                        ? 'border-white bg-white/10 shadow-sm'
                        : 'border-neutral-800 bg-neutral-800/40 hover:bg-neutral-800'
                    }`}
                  >
                    <span
                      className="inline-block w-2.5 h-2.5 rounded-full mr-1.5"
                      style={{
                        backgroundColor:
                          item.color === 'red'
                            ? '#e53935'
                            : item.color === 'blue'
                            ? '#1e88e5'
                            : item.color === 'yellow'
                            ? '#fbc02d'
                            : '#43a047',
                      }}
                    />
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Create Room Button */}
            <div className="bg-neutral-800/50 p-4 rounded-xl border border-neutral-700/40">
              <h3 className="font-semibold text-white mb-1">Host a Private Match</h3>
              <p className="text-xs text-neutral-400 mb-4">
                Generate a unique room code and share it with your friends.
              </p>
              <button
                onClick={handleCreateRoom}
                className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <Users size={18} /> Create Room & Get Code
              </button>
            </div>

            {/* Join Room */}
            <div className="bg-neutral-800/50 p-4 rounded-xl border border-neutral-700/40">
              <h3 className="font-semibold text-white mb-1">Join with Room Code</h3>
              <p className="text-xs text-neutral-400 mb-3">
                Enter the 6-character room code given to you by the host.
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. LR-4921"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  className="flex-1 bg-neutral-900 border border-neutral-700 px-3 py-2.5 rounded-xl text-white font-mono uppercase tracking-wider focus:outline-hidden focus:border-amber-500"
                />
                <button
                  onClick={handleJoinRoom}
                  className="px-5 py-2.5 bg-neutral-700 hover:bg-neutral-600 font-bold rounded-xl transition cursor-pointer"
                >
                  Join
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-5 space-y-5">
            {/* Room Code Display */}
            <div className="text-center bg-neutral-800/60 p-5 rounded-2xl border border-amber-500/40">
              <div className="text-xs text-amber-400 font-semibold uppercase tracking-widest mb-1">
                Your Room Code
              </div>
              <div className="text-3xl font-black font-mono tracking-widest text-white my-2">
                {roomState?.roomId}
              </div>
              <button
                onClick={handleCopyCode}
                className="mt-1 px-4 py-1.5 bg-neutral-700 hover:bg-neutral-600 text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 transition cursor-pointer"
              >
                {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                <span>{copied ? 'Code Copied!' : 'Copy Code to Share'}</span>
              </button>
            </div>

            {/* Player list in lobby */}
            <div>
              <div className="text-xs uppercase font-semibold text-neutral-400 mb-2">
                Players in Room ({roomState?.players.length} / 4)
              </div>
              <div className="space-y-2">
                {roomState?.players.map((p, idx) => (
                  <div
                    key={p.id}
                    className="p-3 bg-neutral-800/80 border border-neutral-700 rounded-xl flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{p.avatar}</span>
                      <div>
                        <div className="font-semibold text-sm flex items-center gap-2">
                          <span>{p.name}</span>
                          {idx === 0 && (
                            <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/40 px-1.5 py-0.5 rounded-sm font-bold">
                              HOST
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-neutral-400 capitalize">{p.color} House</div>
                      </div>
                    </div>
                    <span className="text-xs text-emerald-400 font-medium">Ready</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Start Button (for Host) */}
            <div className="pt-2">
              <button
                onClick={handleLaunchMatch}
                className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-lg"
              >
                <Play size={18} /> Launch 3D Match Now
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
