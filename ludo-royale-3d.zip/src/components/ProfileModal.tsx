/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Trophy, Award, Flame, UserCheck, Shield } from 'lucide-react';
import { profileManager, UserProfile } from '../game/ProfileManager';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AVATAR_OPTIONS = ['👑', '⚔️', '🛡️', '🦁', '🐉', '🎲', '🦅', '💎'];

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const [profile, setProfileState] = useState<UserProfile>(profileManager.getProfile());
  const stats = profileManager.getStats();
  const achievements = profileManager.getAchievements();

  if (!isOpen) return null;

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const updated = { ...profile, name: e.target.value };
    setProfileState(updated);
    profileManager.setProfile(updated);
  };

  const handleAvatarSelect = (av: string) => {
    const updated = { ...profile, avatar: av };
    setProfileState(updated);
    profileManager.setProfile(updated);
  };

  const winRate = stats.gamesPlayed > 0 ? Math.round((stats.gamesWon / stats.gamesPlayed) * 100) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-amber-600/40 rounded-2xl p-6 text-white shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <span className="text-2xl">👤</span>
            <h2 className="text-xl font-bold tracking-wide">Player Profile & Badges</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Profile Customization */}
        <div className="mt-5 bg-neutral-800/50 p-4 rounded-2xl border border-neutral-700/50 flex flex-col sm:flex-row items-center gap-5">
          <div className="w-20 h-20 bg-neutral-700/70 border-2 border-amber-500 rounded-2xl flex items-center justify-center text-4xl shadow-md">
            {profile.avatar}
          </div>

          <div className="flex-1 w-full space-y-3">
            <div>
              <label className="block text-xs uppercase font-semibold text-neutral-400 mb-1">
                Player Nickname
              </label>
              <input
                type="text"
                value={profile.name}
                onChange={handleNameChange}
                maxLength={18}
                className="w-full bg-neutral-900 border border-neutral-700 px-3 py-2 rounded-xl text-white font-semibold focus:outline-hidden focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs uppercase font-semibold text-neutral-400 mb-1">
                Choose Avatar
              </label>
              <div className="flex flex-wrap gap-2">
                {AVATAR_OPTIONS.map((av) => (
                  <button
                    key={av}
                    onClick={() => handleAvatarSelect(av)}
                    className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center border transition cursor-pointer ${
                      profile.avatar === av
                        ? 'border-amber-400 bg-amber-500/20 shadow-xs'
                        : 'border-neutral-700 bg-neutral-900 hover:bg-neutral-700'
                    }`}
                  >
                    {av}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="mt-5">
          <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider mb-3">
            Career Statistics
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-700/40 text-center">
              <div className="text-xs text-neutral-400">Games Played</div>
              <div className="text-xl font-bold mt-0.5 tabular-nums">{stats.gamesPlayed}</div>
            </div>
            <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-700/40 text-center">
              <div className="text-xs text-neutral-400">Victories</div>
              <div className="text-xl font-bold mt-0.5 text-amber-400 tabular-nums">{stats.gamesWon}</div>
            </div>
            <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-700/40 text-center">
              <div className="text-xs text-neutral-400">Win Rate</div>
              <div className="text-xl font-bold mt-0.5 text-emerald-400 tabular-nums">{winRate}%</div>
            </div>
            <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-700/40 text-center">
              <div className="text-xs text-neutral-400">Total XP</div>
              <div className="text-xl font-bold mt-0.5 text-purple-400 tabular-nums">{stats.totalXP}</div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 mt-3">
            <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-700/40 text-center">
              <div className="text-xs text-neutral-400">Tokens Captured</div>
              <div className="text-lg font-bold mt-0.5 text-rose-400 tabular-nums">{stats.tokensCaptured}</div>
            </div>
            <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-700/40 text-center">
              <div className="text-xs text-neutral-400">Sixes Rolled</div>
              <div className="text-lg font-bold mt-0.5 text-yellow-400 tabular-nums">{stats.sixesRolled}</div>
            </div>
            <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-700/40 text-center">
              <div className="text-xs text-neutral-400">Best Streak</div>
              <div className="text-lg font-bold mt-0.5 text-orange-400 tabular-nums">{stats.bestStreak} 🔥</div>
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="mt-6">
          <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider mb-3">
            Achievements ({achievements.filter((a) => a.unlocked).length} / {achievements.length})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {achievements.map((ach) => (
              <div
                key={ach.id}
                className={`p-3 rounded-xl border flex items-center gap-3 transition ${
                  ach.unlocked
                    ? 'bg-neutral-800/80 border-amber-500/50'
                    : 'bg-neutral-900/50 border-neutral-800 opacity-60'
                }`}
              >
                <div className="text-3xl">{ach.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm text-white truncate">{ach.title}</span>
                    <span className="text-xs text-amber-400 font-bold">+{ach.xpReward} XP</span>
                  </div>
                  <div className="text-xs text-neutral-400 mt-0.5 leading-snug">{ach.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold rounded-xl border border-neutral-700 transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
