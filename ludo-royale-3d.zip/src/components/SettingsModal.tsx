/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Volume2, VolumeX, Sparkles, Sliders, RotateCcw } from 'lucide-react';
import { GameSettings, GraphicsQuality } from '../game/types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  const handleChange = <K extends keyof GameSettings>(key: K, value: GameSettings[K]) => {
    onUpdateSettings({ ...settings, [key]: value });
  };

  const resetDefaults = () => {
    onUpdateSettings({
      soundVolume: 0.8,
      musicVolume: 0.35,
      isMuted: false,
      graphicsQuality: 'high',
      reducedMotion: false,
      cameraSensitivity: 1.0,
      allowCameraRotation: true,
      extraTurnOnSix: true,
      threeSixesPenalty: true,
      captureBonusTurn: true,
      homeBonusTurn: true,
      quickMode: false,
      animationSpeed: 1.0,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-xl bg-neutral-900 border border-amber-600/40 rounded-2xl p-6 text-white shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Sliders size={22} className="text-amber-400" />
            <h2 className="text-xl font-bold tracking-wide">Game Settings</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        <div className="mt-5 space-y-6 text-sm">
          {/* Audio Section */}
          <div>
            <h3 className="font-semibold text-amber-400 mb-3 flex items-center gap-2">
              <Volume2 size={16} /> Audio & Synthesizer
            </h3>
            <div className="space-y-3 bg-neutral-800/50 p-4 rounded-xl border border-neutral-700/40">
              <div className="flex items-center justify-between">
                <span>Mute All Audio</span>
                <button
                  onClick={() => handleChange('isMuted', !settings.isMuted)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    settings.isMuted
                      ? 'bg-red-600 text-white'
                      : 'bg-neutral-700 text-neutral-300 hover:bg-neutral-600'
                  }`}
                >
                  {settings.isMuted ? 'Muted' : 'Unmuted'}
                </button>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Sound Effects</span>
                  <span className="tabular-nums text-neutral-400">
                    {Math.round(settings.soundVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={settings.soundVolume}
                  onChange={(e) => handleChange('soundVolume', parseFloat(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>Background Ambient Music</span>
                  <span className="tabular-nums text-neutral-400">
                    {Math.round(settings.musicVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={settings.musicVolume}
                  onChange={(e) => handleChange('musicVolume', parseFloat(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Gameplay & Speed */}
          <div>
            <h3 className="font-semibold text-amber-400 mb-3 flex items-center gap-2">
              <Sparkles size={16} /> Game Pace & Visuals
            </h3>
            <div className="space-y-4 bg-neutral-800/50 p-4 rounded-xl border border-neutral-700/40">
              <div>
                <label className="block mb-2 text-neutral-300">Animation Speed</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Normal (1x)', val: 1.0 },
                    { label: 'Fast (1.5x)', val: 1.5 },
                    { label: 'Turbo (2x)', val: 2.0 },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => handleChange('animationSpeed', opt.val)}
                      className={`py-2 text-xs font-semibold rounded-lg border transition ${
                        settings.animationSpeed === opt.val
                          ? 'bg-amber-500 border-amber-400 text-neutral-950 font-bold'
                          : 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Allow Manual 3D Camera Orbit</div>
                  <div className="text-xs text-neutral-400">Drag to rotate around the board</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.allowCameraRotation}
                  onChange={(e) => handleChange('allowCameraRotation', e.target.checked)}
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Official Rules & House Rules */}
          <div>
            <h3 className="font-semibold text-amber-400 mb-3 flex items-center gap-2">
              📜 Ludo Rules Configuration
            </h3>
            <div className="space-y-3 bg-neutral-800/50 p-4 rounded-xl border border-neutral-700/40">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Quick Match Mode</div>
                  <div className="text-xs text-neutral-400">Only 2 tokens needed to reach home to win</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.quickMode}
                  onChange={(e) => handleChange('quickMode', e.target.checked)}
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Extra Turn on Rolling a 6</div>
                  <div className="text-xs text-neutral-400">Standard official rule</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.extraTurnOnSix}
                  onChange={(e) => handleChange('extraTurnOnSix', e.target.checked)}
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Three Consecutive Sixes Penalty</div>
                  <div className="text-xs text-neutral-400">Turn is forfeited if three 6s are rolled</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.threeSixesPenalty}
                  onChange={(e) => handleChange('threeSixesPenalty', e.target.checked)}
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Capture Grants Bonus Turn</div>
                  <div className="text-xs text-neutral-400">Earn an extra roll when capturing an opponent</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.captureBonusTurn}
                  onChange={(e) => handleChange('captureBonusTurn', e.target.checked)}
                  className="w-5 h-5 accent-amber-500 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 flex items-center justify-between pt-4 border-t border-neutral-800">
          <button
            onClick={resetDefaults}
            className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition cursor-pointer"
          >
            <RotateCcw size={14} /> Reset Defaults
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold rounded-xl transition cursor-pointer"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
