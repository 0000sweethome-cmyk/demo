/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, RotateCcw, Home, Sparkles } from 'lucide-react';
import { PlayerConfig, PlayerColor } from '../game/types';
import { PLAYER_HEX_COLORS } from '../three/Materials';

interface VictoryModalProps {
  winner: PlayerConfig | null;
  onRematch: () => void;
  onHome: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({ winner, onRematch, onHome }) => {
  useEffect(() => {
    if (winner) {
      // Fire confetti bursts
      const count = 200;
      const defaults = {
        origin: { y: 0.7 },
      };

      const fire = (particleRatio: number, opts: confetti.Options) => {
        confetti({
          ...defaults,
          ...opts,
          particleCount: Math.floor(count * particleRatio),
        });
      };

      fire(0.25, {
        spread: 26,
        startVelocity: 55,
      });
      fire(0.2, {
        spread: 60,
      });
      fire(0.35, {
        spread: 100,
        decay: 0.91,
        scalar: 0.8,
      });
      fire(0.1, {
        spread: 120,
        startVelocity: 25,
        decay: 0.92,
        scalar: 1.2,
      });
      fire(0.1, {
        spread: 120,
        startVelocity: 45,
      });
    }
  }, [winner]);

  if (!winner) return null;

  const hexColor = PLAYER_HEX_COLORS[winner.color];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-300">
      <div className="relative w-full max-w-md bg-neutral-900 border-2 border-amber-500/60 rounded-3xl p-8 text-center text-white shadow-2xl overflow-hidden">
        {/* Glow backdrop */}
        <div
          className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full blur-3xl opacity-40"
          style={{ backgroundColor: hexColor }}
        />

        {/* Crown & Trophy Lockup */}
        <div className="relative inline-block mb-4">
          <div className="text-5xl animate-bounce">👑</div>
          <div className="w-20 h-20 mx-auto bg-amber-500/20 border-2 border-amber-400 rounded-full flex items-center justify-center shadow-lg mt-2">
            <Trophy size={42} className="text-amber-400" />
          </div>
        </div>

        <h2 className="text-2xl font-black tracking-wider uppercase text-amber-400">
          Match Won!
        </h2>

        {/* Winner Badge */}
        <div className="my-6 p-4 rounded-2xl bg-neutral-800/80 border border-neutral-700/60 flex items-center justify-center gap-4">
          <span className="text-4xl">{winner.avatar}</span>
          <div className="text-left">
            <div className="text-lg font-bold text-white">{winner.name}</div>
            <div className="flex items-center gap-2 mt-0.5">
              <span
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: hexColor }}
              />
              <span className="text-xs uppercase tracking-wider text-neutral-300 font-semibold">
                {winner.color} House
              </span>
            </div>
          </div>
        </div>

        <div className="text-sm text-neutral-400 mb-6 flex items-center justify-center gap-2">
          <Sparkles size={16} className="text-amber-400" />
          <span>All required tokens arrived safely in the kingdom!</span>
        </div>

        {/* Action CTAs */}
        <div className="space-y-3">
          <button
            onClick={onRematch}
            className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw size={18} /> Play Rematch
          </button>
          <button
            onClick={onHome}
            className="w-full py-3 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold rounded-xl border border-neutral-700 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home size={18} /> Main Menu
          </button>
        </div>
      </div>
    </div>
  );
};
