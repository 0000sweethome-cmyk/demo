/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PlayerColor, TokenState, AIDifficulty, MoveOption } from './types';
import { getTrackIndexForPlayer, SAFE_TRACK_INDICES } from './BoardCoordinates';
import { isSafePosition } from './GameRules';

export function selectAIMove(
  difficulty: AIDifficulty,
  color: PlayerColor,
  legalMoves: MoveOption[],
  allTokens: Record<PlayerColor, TokenState[]>
): MoveOption {
  if (legalMoves.length === 0) {
    throw new Error('No legal moves to choose from');
  }

  if (legalMoves.length === 1) {
    return legalMoves[0];
  }

  switch (difficulty) {
    case 'easy':
      return selectEasyMove(legalMoves);
    case 'medium':
      return selectMediumMove(legalMoves, color, allTokens);
    case 'hard':
      return selectHardMove(legalMoves, color, allTokens);
    case 'expert':
    default:
      return selectExpertMove(legalMoves, color, allTokens);
  }
}

function selectEasyMove(moves: MoveOption[]): MoveOption {
  // Simple random selection
  const idx = Math.floor(Math.random() * moves.length);
  return moves[idx];
}

function selectMediumMove(
  moves: MoveOption[],
  _color: PlayerColor,
  _allTokens: Record<PlayerColor, TokenState[]>
): MoveOption {
  // 1. Prioritize finishing
  const finishMove = moves.find((m) => m.willFinish);
  if (finishMove) return finishMove;

  // 2. Prioritize capturing
  const captureMove = moves.find((m) => m.willCapture);
  if (captureMove) return captureMove;

  // 3. Prioritize moving out of yard
  const yardMove = moves.find((m) => m.fromStep === -1);
  if (yardMove) return yardMove;

  // 4. Move the most advanced token
  return [...moves].sort((a, b) => b.toStep - a.toStep)[0];
}

function selectHardMove(
  moves: MoveOption[],
  color: PlayerColor,
  allTokens: Record<PlayerColor, TokenState[]>
): MoveOption {
  let bestScore = -Infinity;
  let bestMove = moves[0];

  for (const move of moves) {
    let score = 0;

    if (move.willFinish) score += 1000;
    if (move.willCapture) score += 500;
    if (move.willEnterHome) score += 250;
    if (move.fromStep === -1) score += 200; // open token

    // Safe square bonus
    if (isSafePosition(color, move.toStep)) {
      score += 150;
    }

    // Leaving a safe square penalty
    if (move.fromStep >= 0 && isSafePosition(color, move.fromStep)) {
      score -= 80;
    }

    // Advancing bonus
    score += move.toStep * 2;

    // Risk penalty: does this landing spot leave token vulnerable?
    if (move.toStep <= 50 && !isSafePosition(color, move.toStep)) {
      const targetTrack = getTrackIndexForPlayer(color, move.toStep);
      const risk = calculateVulnerability(targetTrack, color, allTokens);
      score -= risk * 120;
    }

    // Add tiny random tie-breaker
    score += Math.random() * 5;

    if (score > bestScore) {
      bestScore = score;
      bestMove = move;
    }
  }

  return bestMove;
}

function selectExpertMove(
  moves: MoveOption[],
  color: PlayerColor,
  allTokens: Record<PlayerColor, TokenState[]>
): MoveOption {
  let bestScore = -Infinity;
  let bestMove = moves[0];

  for (const move of moves) {
    let score = 0;

    // 1. Victory / Reaching Goal
    if (move.willFinish) score += 2000;

    // 2. Capturing Opponent
    if (move.willCapture) score += 800;

    // 3. Entering Safe Home Stretch
    if (move.willEnterHome) score += 400;

    // 4. Moving out of yard
    if (move.fromStep === -1) {
      // If we have 0 or 1 active token on board, exiting yard is critical
      const activeCount = allTokens[color].filter((t) => t.stepIndex >= 0 && !t.isFinished).length;
      score += activeCount <= 1 ? 500 : 300;
    }

    // 5. Landing on a designated Safe Star or Starting Square
    if (isSafePosition(color, move.toStep)) {
      score += 260;
    }

    // 6. Escaping from danger: if current position is vulnerable and opponent is right behind
    if (move.fromStep >= 0 && move.fromStep <= 50 && !isSafePosition(color, move.fromStep)) {
      const currentTrack = getTrackIndexForPlayer(color, move.fromStep);
      const currentThreat = calculateVulnerability(currentTrack, color, allTokens);
      if (currentThreat > 0) {
        score += 350 * currentThreat; // Urgent escape!
      }
    }

    // 7. Danger evaluation of target destination
    if (move.toStep <= 50 && !isSafePosition(color, move.toStep)) {
      const targetTrack = getTrackIndexForPlayer(color, move.toStep);
      const threatAtDest = calculateVulnerability(targetTrack, color, allTokens);
      score -= threatAtDest * 280;
    }

    // 8. Progress weight (tokens closer to home should be pushed forward)
    score += (move.toStep / 56) * 120;

    // Slight variance
    score += Math.random() * 10;

    if (score > bestScore) {
      bestScore = score;
      bestMove = move;
    }
  }

  return bestMove;
}

/**
 * Calculates threat level (0 to 1+) of an opponent reaching `trackIndex` in 1 dice roll.
 */
function calculateVulnerability(
  targetTrackIndex: number,
  myColor: PlayerColor,
  allTokens: Record<PlayerColor, TokenState[]>
): number {
  if (SAFE_TRACK_INDICES.has(targetTrackIndex)) return 0;

  let threat = 0;

  for (const oppColor of ['red', 'blue', 'yellow', 'green'] as PlayerColor[]) {
    if (oppColor === myColor) continue;
    for (const opp of allTokens[oppColor]) {
      if (opp.stepIndex >= 0 && opp.stepIndex <= 50 && !opp.isFinished) {
        const oppTrack = getTrackIndexForPlayer(oppColor, opp.stepIndex);
        // Distance along track clockwise
        const dist = (targetTrackIndex - oppTrack + 52) % 52;
        if (dist >= 1 && dist <= 6) {
          // In striking range for next roll (probability 1/6)
          threat += 1.0;
        }
      }
    }
  }

  return threat;
}
