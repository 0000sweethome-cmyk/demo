/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PlayerColor } from './types';

export interface GridCoord {
  x: number;
  y: number;
}

export interface WorldCoord {
  x: number;
  y: number;
  z: number;
}

export const CELL_SIZE = 0.8;
export const BOARD_SIZE = 15;
export const BOARD_HALF_EXTENT = (BOARD_SIZE * CELL_SIZE) / 2; // 6.0 units
export const BOARD_SURFACE_Y = 0.51; // height of the board top surface

/**
 * 52 steps of the common circular track on 15x15 board.
 * Red starts at index 0.
 * Blue starts at index 13.
 * Yellow starts at index 26.
 * Green starts at index 39.
 */
export const COMMON_TRACK_COORDS: GridCoord[] = [
  // Red side moving down towards Blue
  { x: 1, y: 8 },  // 0: Red Start (Safe)
  { x: 2, y: 8 },  // 1
  { x: 3, y: 8 },  // 2
  { x: 4, y: 8 },  // 3
  { x: 5, y: 8 },  // 4
  { x: 6, y: 9 },  // 5
  { x: 6, y: 10 }, // 6
  { x: 6, y: 11 }, // 7
  { x: 6, y: 12 }, // 8: Safe Star
  { x: 6, y: 13 }, // 9
  { x: 6, y: 14 }, // 10
  { x: 7, y: 14 }, // 11: Turning point bottom

  // Bottom edge going up to Yellow side
  { x: 8, y: 14 }, // 12
  { x: 8, y: 13 }, // 13: Blue Start (Safe)
  { x: 8, y: 12 }, // 14
  { x: 8, y: 11 }, // 15
  { x: 8, y: 10 }, // 16
  { x: 8, y: 9 },  // 17
  { x: 9, y: 8 },  // 18
  { x: 10, y: 8 }, // 19
  { x: 11, y: 8 }, // 20
  { x: 12, y: 8 }, // 21: Safe Star
  { x: 13, y: 8 }, // 22
  { x: 14, y: 8 }, // 23
  { x: 14, y: 7 }, // 24: Turning point right

  // Right edge going left to Green side
  { x: 14, y: 6 }, // 25
  { x: 13, y: 6 }, // 26: Yellow Start (Safe)
  { x: 12, y: 6 }, // 27
  { x: 11, y: 6 }, // 28
  { x: 10, y: 6 }, // 29
  { x: 9, y: 6 },  // 30
  { x: 8, y: 5 },  // 31
  { x: 8, y: 4 },  // 32
  { x: 8, y: 3 },  // 33
  { x: 8, y: 2 },  // 34: Safe Star
  { x: 8, y: 1 },  // 35
  { x: 8, y: 0 },  // 36
  { x: 7, y: 0 },  // 37: Turning point top

  // Top edge going down to Red side
  { x: 6, y: 0 },  // 38
  { x: 6, y: 1 },  // 39: Green Start (Safe)
  { x: 6, y: 2 },  // 40
  { x: 6, y: 3 },  // 41
  { x: 6, y: 4 },  // 42
  { x: 6, y: 5 },  // 43
  { x: 5, y: 6 },  // 44
  { x: 4, y: 6 },  // 45
  { x: 3, y: 6 },  // 46
  { x: 2, y: 6 },  // 47: Safe Star
  { x: 1, y: 6 },  // 48
  { x: 0, y: 6 },  // 49
  { x: 0, y: 7 },  // 50: Turning point left
  { x: 0, y: 8 },  // 51
];

/** Safe indices on the 52-step common track */
export const SAFE_TRACK_INDICES = new Set([0, 8, 13, 21, 26, 34, 39, 47]);

/** Star indices (excluding starting squares) */
export const STAR_TRACK_INDICES = new Set([8, 21, 34, 47]);

/** Track index where player enters the common path upon leaving home */
export const COLOR_START_TRACK_INDEX: Record<PlayerColor, number> = {
  red: 0,
  blue: 13,
  yellow: 26,
  green: 39,
};

/**
 * Colored home columns (5 steps) + center finish (step 57)
 */
export const COLOR_HOME_LANES: Record<PlayerColor, GridCoord[]> = {
  red: [
    { x: 1, y: 7 }, // step 52
    { x: 2, y: 7 }, // step 53
    { x: 3, y: 7 }, // step 54
    { x: 4, y: 7 }, // step 55
    { x: 5, y: 7 }, // step 56
    { x: 6.2, y: 7 }, // step 57 (finish zone)
  ],
  blue: [
    { x: 7, y: 13 }, // step 52
    { x: 7, y: 12 }, // step 53
    { x: 7, y: 11 }, // step 54
    { x: 7, y: 10 }, // step 55
    { x: 7, y: 9 },  // step 56
    { x: 7, y: 7.8 }, // step 57 (finish zone)
  ],
  yellow: [
    { x: 13, y: 7 }, // step 52
    { x: 12, y: 7 }, // step 53
    { x: 11, y: 7 }, // step 54
    { x: 10, y: 7 }, // step 55
    { x: 9, y: 7 },  // step 56
    { x: 7.8, y: 7 }, // step 57 (finish zone)
  ],
  green: [
    { x: 7, y: 1 },  // step 52
    { x: 7, y: 2 },  // step 53
    { x: 7, y: 3 },  // step 54
    { x: 7, y: 4 },  // step 55
    { x: 7, y: 5 },  // step 56
    { x: 7, y: 6.2 }, // step 57 (finish zone)
  ],
};

/** Home yard nest coordinates for 4 tokens */
export const YARD_NEST_COORDS: Record<PlayerColor, GridCoord[]> = {
  red: [
    { x: 1.8, y: 10.8 },
    { x: 3.6, y: 10.8 },
    { x: 1.8, y: 12.6 },
    { x: 3.6, y: 12.6 },
  ],
  blue: [
    { x: 10.8, y: 10.8 },
    { x: 12.6, y: 10.8 },
    { x: 10.8, y: 12.6 },
    { x: 12.6, y: 12.6 },
  ],
  yellow: [
    { x: 10.8, y: 1.8 },
    { x: 12.6, y: 1.8 },
    { x: 10.8, y: 3.6 },
    { x: 12.6, y: 3.6 },
  ],
  green: [
    { x: 1.8, y: 1.8 },
    { x: 3.6, y: 1.8 },
    { x: 1.8, y: 3.6 },
    { x: 3.6, y: 3.6 },
  ],
};

/** Converts 2D grid coordinates (0..14) to 3D world space (X, Y, Z) */
export function gridToWorld(gridX: number, gridY: number, offsetY = 0): WorldCoord {
  const worldX = (gridX - 7) * CELL_SIZE;
  const worldZ = (gridY - 7) * CELL_SIZE;
  return {
    x: worldX,
    y: BOARD_SURFACE_Y + offsetY,
    z: worldZ,
  };
}

/**
 * Calculates global track index (0..51) for a given player and their progress (0..50).
 */
export function getTrackIndexForPlayer(color: PlayerColor, progress: number): number {
  const startIdx = COLOR_START_TRACK_INDEX[color];
  return (startIdx + progress) % 52;
}

/**
 * Gets 3D world coordinate for a token at a given step (or in yard).
 * @param color Player color
 * @param tokenId Token index (0..3)
 * @param stepIndex -1 for yard, 0..50 for common track, 51..56 for home lane & finish
 */
export function getTokenWorldPosition(
  color: PlayerColor,
  tokenId: number,
  stepIndex: number
): WorldCoord {
  if (stepIndex === -1) {
    // In Yard
    const nest = YARD_NEST_COORDS[color][tokenId] || { x: 2, y: 2 };
    return gridToWorld(nest.x, nest.y);
  }

  if (stepIndex <= 50) {
    // On common track
    const trackIdx = getTrackIndexForPlayer(color, stepIndex);
    const coord = COMMON_TRACK_COORDS[trackIdx];
    return gridToWorld(coord.x, coord.y);
  }

  // In home lane (51 to 56)
  const homeIdx = Math.min(stepIndex - 51, COLOR_HOME_LANES[color].length - 1);
  const coord = COLOR_HOME_LANES[color][homeIdx];
  return gridToWorld(coord.x, coord.y);
}
