/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  PlayerColor,
  PlayerConfig,
  TokenState,
  GameSettings,
  GamePhase,
  MoveOption,
  MatchHistoryEntry,
} from './types';
import {
  getLegalMovesForPlayer,
  executeMove,
  hasPlayerWon,
  MAX_STEP,
} from './GameRules';
import { selectAIMove } from './AIPlayer';

export interface GameEngineState {
  phase: GamePhase;
  players: PlayerConfig[];
  activePlayerIndex: number;
  diceRoll: number | null;
  sixesStreak: number;
  tokens: Record<PlayerColor, TokenState[]>;
  legalMoves: MoveOption[];
  selectedTokenId: number | null;
  winner: PlayerConfig | null;
  rankings: PlayerConfig[];
  turnCount: number;
  statusMessage: string;
}

export type StateListener = (state: GameEngineState) => void;

export class GameEngine {
  public state: GameEngineState;
  private settings: GameSettings;
  private listeners: StateListener[] = [];
  private aiTimeoutId: number | null = null;
  private turnTimerId: number | null = null;

  // Callbacks for Scene / Audio
  public onPerformDiceRoll?: (targetResult: number, playerColor: PlayerColor, onComplete: () => void) => void;
  public onPerformTokenMove?: (
    color: PlayerColor,
    tokenId: number,
    fromStep: number,
    toStep: number,
    speedMultiplier: number,
    onComplete: () => void
  ) => void;
  public onPerformCapture?: (
    victimColor: PlayerColor,
    victimTokenId: number,
    attackerColor: PlayerColor,
    attackerTokenId: number,
    onComplete: () => void
  ) => void;
  public onVictory?: (winner: PlayerConfig) => void;
  public onGameStatsUpdate?: (statsDelta: { won: boolean; captures: number; sixes: number }) => void;

  constructor(players: PlayerConfig[], settings: GameSettings) {
    this.settings = settings;

    this.state = {
      phase: 'idle',
      players,
      activePlayerIndex: 0,
      diceRoll: null,
      sixesStreak: 0,
      tokens: this.createInitialTokens(),
      legalMoves: [],
      selectedTokenId: null,
      winner: null,
      rankings: [],
      turnCount: 1,
      statusMessage: `${players[0]?.name || 'Red'}'s turn to roll!`,
    };
  }

  private createInitialTokens(): Record<PlayerColor, TokenState[]> {
    const createFour = (color: PlayerColor): TokenState[] => [
      { id: 0, color, stepIndex: -1, isFinished: false },
      { id: 1, color, stepIndex: -1, isFinished: false },
      { id: 2, color, stepIndex: -1, isFinished: false },
      { id: 3, color, stepIndex: -1, isFinished: false },
    ];

    return {
      red: createFour('red'),
      blue: createFour('blue'),
      yellow: createFour('yellow'),
      green: createFour('green'),
    };
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.push(listener);
    listener(this.state);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l({ ...this.state }));
  }

  public getActivePlayer(): PlayerConfig {
    return this.state.players[this.state.activePlayerIndex];
  }

  public updateSettings(newSettings: GameSettings) {
    this.settings = newSettings;
  }

  /**
   * Starts a new match.
   */
  public startMatch() {
    this.clearTimeouts();
    this.state.phase = 'idle';
    this.state.activePlayerIndex = 0;
    this.state.diceRoll = null;
    this.state.sixesStreak = 0;
    this.state.tokens = this.createInitialTokens();
    this.state.legalMoves = [];
    this.state.selectedTokenId = null;
    this.state.winner = null;
    this.state.rankings = [];
    this.state.turnCount = 1;

    const active = this.getActivePlayer();
    this.state.statusMessage = `${active.name}'s turn to roll!`;
    this.notify();

    // If active player is AI, trigger auto-roll
    this.checkAITurn();
  }

  /**
   * Generates fair authoritative dice roll (1..6) and initiates animation.
   */
  public rollDice() {
    if (this.state.phase !== 'idle') return;

    const active = this.getActivePlayer();
    this.state.phase = 'rolling';
    this.state.statusMessage = `${active.name} is rolling the dice...`;
    this.notify();

    // Authoritative pseudo-random roll (1-6)
    const roll = Math.floor(Math.random() * 6) + 1;
    this.state.diceRoll = roll;

    // Track sixes streak
    if (roll === 6) {
      this.state.sixesStreak += 1;
      this.onGameStatsUpdate?.({ won: false, captures: 0, sixes: 1 });
    } else {
      this.state.sixesStreak = 0;
    }

    if (this.onPerformDiceRoll) {
      this.onPerformDiceRoll(roll, active.color, () => {
        this.handleDiceRollSettled(roll);
      });
    } else {
      this.handleDiceRollSettled(roll);
    }
  }

  private handleDiceRollSettled(roll: number) {
    const active = this.getActivePlayer();

    // Rule Check: Three consecutive sixes penalty
    if (this.settings.threeSixesPenalty && this.state.sixesStreak >= 3) {
      this.state.statusMessage = `3 Sixes in a row! Turn forfeited for ${active.name}.`;
      this.state.sixesStreak = 0;
      this.notify();

      setTimeout(() => {
        this.advanceToNextTurn();
      }, 1200 / this.settings.animationSpeed);
      return;
    }

    // Determine legal moves for active player
    const playerTokens = this.state.tokens[active.color];
    const legalMoves = getLegalMovesForPlayer(
      active.color,
      playerTokens,
      roll,
      this.state.tokens
    );

    this.state.legalMoves = legalMoves;

    if (legalMoves.length === 0) {
      this.state.phase = 'resolving';
      this.state.statusMessage = `No legal moves for ${active.name} with a ${roll}.`;
      this.notify();

      setTimeout(() => {
        this.advanceToNextTurn();
      }, 900 / this.settings.animationSpeed);
      return;
    }

    // If exactly 1 legal move, auto-select it or let player click
    if (active.type === 'human' && legalMoves.length === 1) {
      this.state.phase = 'waiting_for_move';
      this.state.statusMessage = `${active.name} rolled a ${roll}! Tap your token to move.`;
      this.notify();
    } else if (active.type === 'human') {
      this.state.phase = 'waiting_for_move';
      this.state.statusMessage = `${active.name} rolled a ${roll}! Select a token to move.`;
      this.notify();
    } else {
      // AI Move
      this.state.phase = 'waiting_for_move';
      this.state.statusMessage = `${active.name} rolled a ${roll} and is thinking...`;
      this.notify();

      const chosenMove = selectAIMove(
        active.difficulty || 'medium',
        active.color,
        legalMoves,
        this.state.tokens
      );

      this.aiTimeoutId = window.setTimeout(() => {
        this.selectTokenAndMove(chosenMove.tokenId);
      }, 700 / this.settings.animationSpeed);
    }
  }

  /**
   * Player or AI selects a token to move.
   */
  public selectTokenAndMove(tokenId: number) {
    if (this.state.phase !== 'waiting_for_move') return;

    const move = this.state.legalMoves.find((m) => m.tokenId === tokenId);
    if (!move) return;

    const active = this.getActivePlayer();
    const roll = this.state.diceRoll!;

    this.state.phase = 'token_moving';
    this.state.selectedTokenId = tokenId;
    this.state.legalMoves = [];
    this.notify();

    if (this.onPerformTokenMove) {
      this.onPerformTokenMove(
        active.color,
        tokenId,
        move.fromStep,
        move.toStep,
        this.settings.animationSpeed,
        () => {
          this.resolveMoveExecution(active, tokenId, roll);
        }
      );
    } else {
      this.resolveMoveExecution(active, tokenId, roll);
    }
  }

  private resolveMoveExecution(active: PlayerConfig, tokenId: number, roll: number) {
    this.state.phase = 'resolving';

    const execResult = executeMove(
      active.color,
      tokenId,
      roll,
      this.state.tokens,
      this.settings,
      this.state.sixesStreak
    );

    this.state.tokens = execResult.nextTokens;

    // Check Capture
    if (execResult.capturedToken) {
      this.state.statusMessage = `💥 ${active.name} captured ${execResult.capturedToken.color.toUpperCase()}'s token!`;
      this.onGameStatsUpdate?.({ won: false, captures: 1, sixes: 0 });

      if (this.onPerformCapture) {
        this.onPerformCapture(
          execResult.capturedToken.color,
          execResult.capturedToken.id,
          active.color,
          tokenId,
          () => {
            this.checkPostMoveState(active, execResult.grantBonusTurn);
          }
        );
        return;
      }
    }

    if (execResult.finished) {
      this.state.statusMessage = `🌟 Token reached home for ${active.name}!`;
    }

    this.checkPostMoveState(active, execResult.grantBonusTurn);
  }

  private checkPostMoveState(active: PlayerConfig, grantBonusTurn: boolean) {
    // Check Win Condition
    const playerTokens = this.state.tokens[active.color];
    const won = hasPlayerWon(playerTokens, this.settings.quickMode);

    if (won) {
      this.state.phase = 'game_over';
      this.state.winner = active;
      if (!this.state.rankings.includes(active)) {
        this.state.rankings.push(active);
      }
      this.state.statusMessage = `🏆 VICTORY! ${active.name} wins the match!`;
      this.onGameStatsUpdate?.({ won: active.type === 'human', captures: 0, sixes: 0 });
      this.onVictory?.(active);
      this.notify();
      return;
    }

    if (grantBonusTurn) {
      this.state.phase = 'idle';
      this.state.diceRoll = null;
      this.state.selectedTokenId = null;
      this.state.statusMessage = `🎉 Bonus turn for ${active.name}! Roll again.`;
      this.notify();
      this.checkAITurn();
    } else {
      this.advanceToNextTurn();
    }
  }

  private advanceToNextTurn() {
    this.state.phase = 'idle';
    this.state.diceRoll = null;
    this.state.selectedTokenId = null;
    this.state.sixesStreak = 0;
    this.state.legalMoves = [];

    // Advance player index
    this.state.activePlayerIndex = (this.state.activePlayerIndex + 1) % this.state.players.length;
    this.state.turnCount += 1;

    const nextPlayer = this.getActivePlayer();
    this.state.statusMessage = `${nextPlayer.name}'s turn to roll!`;
    this.notify();

    this.checkAITurn();
  }

  private checkAITurn() {
    const active = this.getActivePlayer();
    if (active.type === 'ai' && this.state.phase === 'idle') {
      this.aiTimeoutId = window.setTimeout(() => {
        this.rollDice();
      }, 700 / this.settings.animationSpeed);
    }
  }

  private clearTimeouts() {
    if (this.aiTimeoutId) {
      clearTimeout(this.aiTimeoutId);
      this.aiTimeoutId = null;
    }
    if (this.turnTimerId) {
      clearTimeout(this.turnTimerId);
      this.turnTimerId = null;
    }
  }

  public dispose() {
    this.clearTimeouts();
    this.listeners = [];
  }
}
