/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PlayerColor, TokenState, GameSettings, MoveOption } from './types';
import {
  SAFE_TRACK_INDICES,
  getTrackIndexForPlayer,
} from './BoardCoordinates';

export const MAX_STEP = 56; // 0..50 common track, 51..55 colored lane, 56 = HOME FINISHED

/**
 * Checks if a specific step position for a given player color is a safe square.
 */
export function isSafePosition(color: PlayerColor, stepIndex: number): boolean {
  if (stepIndex === -1) return true; // in yard
  if (stepIndex > 50) return true; // in home lane or finish
  const trackIdx = getTrackIndexForPlayer(color, stepIndex);
  return SAFE_TRACK_INDICES.has(trackIdx);
}

/**
 * Validates whether a token can legally move given the rolled dice number.
 */
export function canMoveToken(
  token: TokenState,
  diceRoll: number,
  allTokens: Record<PlayerColor, TokenState[]>
): { canMove: boolean; targetStep: number; willCapture: boolean; willEnterHome: boolean; willFinish: boolean } {
  if (token.isFinished) {
    return { canMove: false, targetStep: -1, willCapture: false, willEnterHome: false, willFinish: false };
  }

  // Token is in Yard
  if (token.stepIndex === -1) {
    if (diceRoll === 6) {
      // Leaves yard to step 0
      const targetStep = 0;
      const willCapture = checkCaptureAtStep(token.color, targetStep, allTokens);
      return {
        canMove: true,
        targetStep,
        willCapture,
        willEnterHome: false,
        willFinish: false,
      };
    }
    return { canMove: false, targetStep: -1, willCapture: false, willEnterHome: false, willFinish: false };
  }

  // Token is on track or home lane
  const targetStep = token.stepIndex + diceRoll;

  // Cannot overshoot the home goal
  if (targetStep > MAX_STEP) {
    return { canMove: false, targetStep: -1, willCapture: false, willEnterHome: false, willFinish: false };
  }

  const willFinish = targetStep === MAX_STEP;
  const willEnterHome = token.stepIndex <= 50 && targetStep > 50;
  const willCapture = targetStep <= 50 ? checkCaptureAtStep(token.color, targetStep, allTokens) : false;

  return {
    canMove: true,
    targetStep,
    willCapture,
    willEnterHome,
    willFinish,
  };
}

/**
 * Checks whether landing at a target step will capture any opponent token.
 */
export function checkCaptureAtStep(
  movingColor: PlayerColor,
  targetStep: number,
  allTokens: Record<PlayerColor, TokenState[]>
): boolean {
  if (targetStep < 0 || targetStep > 50) return false;

  const targetTrackIdx = getTrackIndexForPlayer(movingColor, targetStep);
  if (SAFE_TRACK_INDICES.has(targetTrackIdx)) return false;

  for (const color of ['red', 'blue', 'yellow', 'green'] as PlayerColor[]) {
    if (color === movingColor) continue;
    const opponentTokens = allTokens[color] || [];
    for (const opp of opponentTokens) {
      if (opp.stepIndex >= 0 && opp.stepIndex <= 50 && !opp.isFinished) {
        const oppTrackIdx = getTrackIndexForPlayer(color, opp.stepIndex);
        if (oppTrackIdx === targetTrackIdx) {
          return true;
        }
      }
    }
  }

  return false;
}

/**
 * Returns all legal move options for a player given their tokens and current dice roll.
 */
export function getLegalMovesForPlayer(
  color: PlayerColor,
  playerTokens: TokenState[],
  diceRoll: number,
  allTokens: Record<PlayerColor, TokenState[]>
): MoveOption[] {
  const options: MoveOption[] = [];

  for (const token of playerTokens) {
    const check = canMoveToken(token, diceRoll, allTokens);
    if (check.canMove) {
      options.push({
        tokenId: token.id,
        fromStep: token.stepIndex,
        toStep: check.targetStep,
        willCapture: check.willCapture,
        willEnterHome: check.willEnterHome,
        willFinish: check.willFinish,
      });
    }
  }

  return options;
}

export interface MoveExecutionResult {
  nextTokens: Record<PlayerColor, TokenState[]>;
  capturedToken: { color: PlayerColor; id: number } | null;
  enteredHome: boolean;
  finished: boolean;
  grantBonusTurn: boolean;
}

/**
 * Executes a move, handles captures, and returns updated token states.
 */
export function executeMove(
  color: PlayerColor,
  tokenId: number,
  diceRoll: number,
  allTokens: Record<PlayerColor, TokenState[]>,
  settings: GameSettings,
  sixesStreak: number
): MoveExecutionResult {
  // Deep clone token state
  const nextTokens: Record<PlayerColor, TokenState[]> = {
    red: allTokens.red.map((t) => ({ ...t })),
    blue: allTokens.blue.map((t) => ({ ...t })),
    yellow: allTokens.yellow.map((t) => ({ ...t })),
    green: allTokens.green.map((t) => ({ ...t })),
  };

  const movingToken = nextTokens[color].find((t) => t.id === tokenId);
  if (!movingToken) {
    throw new Error(`Token ${tokenId} not found for player ${color}`);
  }

  const prevStep = movingToken.stepIndex;
  let targetStep = prevStep === -1 ? 0 : prevStep + diceRoll;
  if (targetStep > MAX_STEP) targetStep = prevStep; // safety fallback

  movingToken.stepIndex = targetStep;
  const finished = targetStep === MAX_STEP;
  if (finished) {
    movingToken.isFinished = true;
  }

  const enteredHome = prevStep <= 50 && targetStep > 50;

  // Check captures if landing on common track
  let capturedToken: { color: PlayerColor; id: number } | null = null;
  if (targetStep >= 0 && targetStep <= 50) {
    const landingTrackIdx = getTrackIndexForPlayer(color, targetStep);
    if (!SAFE_TRACK_INDICES.has(landingTrackIdx)) {
      for (const oppColor of ['red', 'blue', 'yellow', 'green'] as PlayerColor[]) {
        if (oppColor === color) continue;
        for (const opp of nextTokens[oppColor]) {
          if (opp.stepIndex >= 0 && opp.stepIndex <= 50 && !opp.isFinished) {
            const oppTrackIdx = getTrackIndexForPlayer(oppColor, opp.stepIndex);
            if (oppTrackIdx === landingTrackIdx) {
              // Capture!
              opp.stepIndex = -1; // sent back to yard
              capturedToken = { color: oppColor, id: opp.id };
              break; // capture first opponent token on square
            }
          }
        }
        if (capturedToken) break;
      }
    }
  }

  // Determine bonus turn:
  // 1. Rolled a 6 (if enabled and didn't hit 3 sixes penalty)
  // 2. Captured an opponent (if enabled)
  // 3. Reached home goal (if enabled)
  let grantBonusTurn = false;

  if (settings.extraTurnOnSix && diceRoll === 6) {
    if (!settings.threeSixesPenalty || sixesStreak < 3) {
      grantBonusTurn = true;
    }
  }

  if (settings.captureBonusTurn && capturedToken) {
    grantBonusTurn = true;
  }

  if (settings.homeBonusTurn && finished) {
    grantBonusTurn = true;
  }

  return {
    nextTokens,
    capturedToken,
    enteredHome,
    finished,
    grantBonusTurn,
  };
}

/**
 * Checks if a player has met the winning condition.
 */
export function hasPlayerWon(
  playerTokens: TokenState[],
  quickMode: boolean
): boolean {
  const finishedCount = playerTokens.filter((t) => t.isFinished).length;
  const targetToWin = quickMode ? 2 : 4;
  return finishedCount >= targetToWin;
}
