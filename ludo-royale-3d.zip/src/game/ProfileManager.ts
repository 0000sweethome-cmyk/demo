/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GameStats, MatchHistoryEntry, Achievement, PlayerColor } from './types';

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_win',
    title: 'Royale Champion',
    description: 'Win your first game of Ludo Royale 3D',
    icon: '👑',
    unlocked: false,
    xpReward: 150,
  },
  {
    id: 'first_capture',
    title: 'Strike Master',
    description: 'Capture an opponent token on a vulnerable square',
    icon: '⚔️',
    unlocked: false,
    xpReward: 50,
  },
  {
    id: 'lucky_six',
    title: 'High Roller',
    description: 'Roll a 6 on the 3D dice',
    icon: '🎲',
    unlocked: false,
    xpReward: 30,
  },
  {
    id: 'streak_3',
    title: 'Unstoppable',
    description: 'Win 3 matches in a row',
    icon: '🔥',
    unlocked: false,
    xpReward: 250,
  },
  {
    id: 'safe_haven',
    title: 'Tactical Shield',
    description: 'Land on a safe star square',
    icon: '⭐',
    unlocked: false,
    xpReward: 40,
  },
  {
    id: 'home_sweet_home',
    title: 'Grand Finish',
    description: 'Successfully bring all 4 tokens to the home finish zone',
    icon: '🏰',
    unlocked: false,
    xpReward: 200,
  },
];

const STATS_STORAGE_KEY = 'ludo_royale_stats_v1';
const HISTORY_STORAGE_KEY = 'ludo_royale_history_v1';
const ACHIEVEMENTS_STORAGE_KEY = 'ludo_royale_achievements_v1';
const PROFILE_STORAGE_KEY = 'ludo_royale_profile_v1';

export interface UserProfile {
  name: string;
  avatar: string;
  preferredColor: PlayerColor;
}

export class ProfileManager {
  private stats: GameStats;
  private history: MatchHistoryEntry[];
  private achievements: Achievement[];
  private profile: UserProfile;

  constructor() {
    this.stats = this.loadStats();
    this.history = this.loadHistory();
    this.achievements = this.loadAchievements();
    this.profile = this.loadProfile();
  }

  private loadStats(): GameStats {
    try {
      const data = localStorage.getItem(STATS_STORAGE_KEY);
      if (data) return JSON.parse(data);
    } catch {}
    return {
      gamesPlayed: 0,
      gamesWon: 0,
      tokensCaptured: 0,
      tokensLost: 0,
      sixesRolled: 0,
      winStreak: 0,
      bestStreak: 0,
      totalXP: 100,
    };
  }

  private loadHistory(): MatchHistoryEntry[] {
    try {
      const data = localStorage.getItem(HISTORY_STORAGE_KEY);
      if (data) return JSON.parse(data);
    } catch {}
    return [];
  }

  private loadAchievements(): Achievement[] {
    try {
      const data = localStorage.getItem(ACHIEVEMENTS_STORAGE_KEY);
      if (data) return JSON.parse(data);
    } catch {}
    return INITIAL_ACHIEVEMENTS;
  }

  private loadProfile(): UserProfile {
    try {
      const data = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (data) return JSON.parse(data);
    } catch {}
    return {
      name: 'Grandmaster',
      avatar: '👑',
      preferredColor: 'red',
    };
  }

  public getProfile(): UserProfile {
    return { ...this.profile };
  }

  public setProfile(profile: UserProfile) {
    this.profile = profile;
    localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
  }

  public getStats(): GameStats {
    return { ...this.stats };
  }

  public getHistory(): MatchHistoryEntry[] {
    return [...this.history];
  }

  public getAchievements(): Achievement[] {
    return [...this.achievements];
  }

  public recordMatchEnd(won: boolean, mode: 'vs_ai' | 'local' | 'online', winnerName: string, winnerColor: PlayerColor, durationSeconds: number) {
    this.stats.gamesPlayed += 1;
    if (won) {
      this.stats.gamesWon += 1;
      this.stats.winStreak += 1;
      this.stats.bestStreak = Math.max(this.stats.bestStreak, this.stats.winStreak);
      this.stats.totalXP += 100;
      this.unlockAchievement('first_win');
      if (this.stats.winStreak >= 3) {
        this.unlockAchievement('streak_3');
      }
    } else {
      this.stats.winStreak = 0;
      this.stats.totalXP += 25;
    }

    const entry: MatchHistoryEntry = {
      id: 'match_' + Date.now(),
      date: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      mode,
      winnerColor,
      winnerName,
      playerRank: won ? 1 : 2,
      durationSeconds,
    };

    this.history.unshift(entry);
    if (this.history.length > 20) this.history.pop();

    this.saveAll();
  }

  public recordDelta(captures: number, sixes: number) {
    if (captures > 0) {
      this.stats.tokensCaptured += captures;
      this.stats.totalXP += captures * 15;
      this.unlockAchievement('first_capture');
    }
    if (sixes > 0) {
      this.stats.sixesRolled += sixes;
      this.stats.totalXP += sixes * 5;
      this.unlockAchievement('lucky_six');
    }
    this.saveAll();
  }

  public unlockAchievement(id: string) {
    const ach = this.achievements.find((a) => a.id === id);
    if (ach && !ach.unlocked) {
      ach.unlocked = true;
      ach.unlockedAt = new Date().toLocaleDateString();
      this.stats.totalXP += ach.xpReward;
      this.saveAll();
    }
  }

  private saveAll() {
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(this.stats));
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(this.history));
      localStorage.setItem(ACHIEVEMENTS_STORAGE_KEY, JSON.stringify(this.achievements));
    } catch {}
  }
}

export const profileManager = new ProfileManager();
