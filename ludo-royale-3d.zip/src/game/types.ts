/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PlayerColor = 'red' | 'green' | 'yellow' | 'blue';

export type PlayerType = 'human' | 'ai' | 'online_remote';

export type AIDifficulty = 'easy' | 'medium' | 'hard' | 'expert';

export type GraphicsQuality = 'low' | 'medium' | 'high' | 'ultra';

export type CameraViewMode = 'isometric' | 'topdown' | 'active_player' | 'free';

export interface PlayerConfig {
  id: string;
  name: string;
  color: PlayerColor;
  type: PlayerType;
  difficulty?: AIDifficulty;
  avatar: string;
}

export interface TokenState {
  id: number; // 0, 1, 2, 3 per color
  color: PlayerColor;
  // Position:
  // -1: in home yard / nest
  // 0 to 51: on common track (relative to player's track mapping or absolute index 0..51)
  // 100 to 104: in colored home stretch (steps 1, 2, 3, 4, 5)
  // 105: finished / home goal
  stepIndex: number; // -1: yard, 0..51: main track, 52..56: home lane, 57: finished
  isFinished: boolean;
}

export interface MoveOption {
  tokenId: number;
  fromStep: number;
  toStep: number;
  willCapture: boolean;
  willEnterHome: boolean;
  willFinish: boolean;
}

export type GamePhase =
  | 'idle'
  | 'rolling'
  | 'waiting_for_move'
  | 'token_moving'
  | 'resolving'
  | 'turn_transition'
  | 'game_over';

export interface GameSettings {
  // Audio
  soundVolume: number;
  musicVolume: number;
  isMuted: boolean;
  
  // Graphics
  graphicsQuality: GraphicsQuality;
  reducedMotion: boolean;
  cameraSensitivity: number;
  allowCameraRotation: boolean;
  
  // Game Rules
  extraTurnOnSix: boolean;
  threeSixesPenalty: boolean;
  captureBonusTurn: boolean;
  homeBonusTurn: boolean;
  quickMode: boolean; // only 2 tokens need to reach home to win
  animationSpeed: number; // 1 = normal, 1.5 = fast, 2 = turbo
}

export interface GameStats {
  gamesPlayed: number;
  gamesWon: number;
  tokensCaptured: number;
  tokensLost: number;
  sixesRolled: number;
  winStreak: number;
  bestStreak: number;
  totalXP: number;
}

export interface MatchHistoryEntry {
  id: string;
  date: string;
  mode: 'vs_ai' | 'local' | 'online';
  winnerColor: PlayerColor;
  winnerName: string;
  playerRank: number;
  durationSeconds: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  xpReward: number;
}
