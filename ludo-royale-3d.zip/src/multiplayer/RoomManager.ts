/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PlayerColor, PlayerConfig, TokenState } from '../game/types';

export interface RoomState {
  roomId: string;
  hostId: string;
  players: PlayerConfig[];
  isStarted: boolean;
  activeColor: PlayerColor;
  turnIndex: number;
}

export interface MultiplayerMessage {
  type: 'JOIN' | 'START' | 'ROLL' | 'MOVE' | 'RESTART' | 'CHAT';
  senderId: string;
  senderName: string;
  roomId: string;
  payload: any;
  timestamp: number;
}

export type MessageHandler = (msg: MultiplayerMessage) => void;

class RoomManager {
  private channel: BroadcastChannel | null = null;
  private messageHandlers: MessageHandler[] = [];
  public currentRoom: RoomState | null = null;
  public myPlayerId: string;
  public isHost = false;

  constructor() {
    this.myPlayerId = 'player_' + Math.random().toString(36).substring(2, 9);
  }

  public createRoom(hostName: string, hostColor: PlayerColor): RoomState {
    const code = 'LR-' + Math.floor(1000 + Math.random() * 9000);
    this.isHost = true;

    const hostPlayer: PlayerConfig = {
      id: this.myPlayerId,
      name: hostName || 'Host',
      color: hostColor,
      type: 'human',
      avatar: '👑',
    };

    this.currentRoom = {
      roomId: code,
      hostId: this.myPlayerId,
      players: [hostPlayer],
      isStarted: false,
      activeColor: hostColor,
      turnIndex: 0,
    };

    this.connectChannel(code);
    return this.currentRoom;
  }

  public joinRoom(roomCode: string, playerName: string, preferredColor?: PlayerColor): boolean {
    const formatted = roomCode.trim().toUpperCase();
    this.isHost = false;

    // Available colors
    const colors: PlayerColor[] = ['red', 'blue', 'yellow', 'green'];
    const chosenColor = preferredColor || colors[1];

    const player: PlayerConfig = {
      id: this.myPlayerId,
      name: playerName || 'Challenger',
      color: chosenColor,
      type: 'human',
      avatar: '⚔️',
    };

    this.currentRoom = {
      roomId: formatted,
      hostId: 'remote_host',
      players: [player],
      isStarted: false,
      activeColor: 'red',
      turnIndex: 0,
    };

    this.connectChannel(formatted);

    // Send JOIN broadcast
    this.sendMessage({
      type: 'JOIN',
      senderId: this.myPlayerId,
      senderName: playerName,
      roomId: formatted,
      payload: { player },
      timestamp: Date.now(),
    });

    return true;
  }

  private connectChannel(roomId: string) {
    if (this.channel) {
      this.channel.close();
    }

    try {
      this.channel = new BroadcastChannel(`ludo_room_${roomId}`);
      this.channel.onmessage = (event) => {
        const msg = event.data as MultiplayerMessage;
        if (msg && msg.roomId === roomId && msg.senderId !== this.myPlayerId) {
          this.handleIncomingMessage(msg);
        }
      };
    } catch {
      // BroadcastChannel fallback if in restricted iframe
    }
  }

  private handleIncomingMessage(msg: MultiplayerMessage) {
    if (msg.type === 'JOIN' && this.isHost && this.currentRoom) {
      const newPlayer = msg.payload.player as PlayerConfig;
      // Ensure unique color
      const usedColors = this.currentRoom.players.map((p) => p.color);
      const allColors: PlayerColor[] = ['red', 'blue', 'yellow', 'green'];
      const available = allColors.find((c) => !usedColors.includes(c)) || 'blue';
      newPlayer.color = available;

      if (!this.currentRoom.players.some((p) => p.id === newPlayer.id)) {
        this.currentRoom.players.push(newPlayer);
        // Reply with updated room state
        this.sendMessage({
          type: 'START',
          senderId: this.myPlayerId,
          senderName: 'Host',
          roomId: this.currentRoom.roomId,
          payload: { room: this.currentRoom },
          timestamp: Date.now(),
        });
      }
    } else if (msg.type === 'START' && !this.isHost && msg.payload.room) {
      this.currentRoom = msg.payload.room;
    }

    this.messageHandlers.forEach((handler) => handler(msg));
  }

  public sendMessage(msg: MultiplayerMessage) {
    if (this.channel) {
      this.channel.postMessage(msg);
    }
  }

  public onMessage(handler: MessageHandler): () => void {
    this.messageHandlers.push(handler);
    return () => {
      this.messageHandlers = this.messageHandlers.filter((h) => h !== handler);
    };
  }

  public leaveRoom() {
    if (this.channel) {
      this.channel.close();
      this.channel = null;
    }
    this.currentRoom = null;
    this.isHost = false;
  }
}

export const roomManager = new RoomManager();
