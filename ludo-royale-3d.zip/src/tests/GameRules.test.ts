/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  canMoveToken,
  getLegalMovesForPlayer,
  executeMove,
  hasPlayerWon,
  isSafePosition,
  MAX_STEP,
} from '../game/GameRules';
import { PlayerColor, TokenState, GameSettings } from '../game/types';
import { COLOR_START_TRACK_INDEX, getTrackIndexForPlayer } from '../game/BoardCoordinates';

function createMockTokens(): Record<PlayerColor, TokenState[]> {
  const createFour = (color: PlayerColor): TokenState[] => [
    { id: 0, color, stepIndex: -1, isFinished: false },
    { id: 1, color, stepIndex: -1, isFinished: false },
    { id: 2, color, stepIndex: -1, isFinished: false },
    { id: 3, color, stepIndex: -1, isFinished: false },
  ];
  return {
    red: createFour('red'),
    blue: createFour('blue'),
    yellow: createFour('yellow'),
    green: createFour('green'),
  };
}

const defaultSettings: GameSettings = {
  soundVolume: 0.8,
  musicVolume: 0.3,
  isMuted: false,
  graphicsQuality: 'high',
  reducedMotion: false,
  cameraSensitivity: 1.0,
  allowCameraRotation: true,
  extraTurnOnSix: true,
  threeSixesPenalty: true,
  captureBonusTurn: true,
  homeBonusTurn: true,
  quickMode: false,
  animationSpeed: 1.0,
};

function runTests() {
  console.log('🧪 Starting Ludo Royale 3D Automated Rules Tests...');
  let passed = 0;
  let total = 0;

  function assert(condition: boolean, testName: string) {
    total++;
    if (condition) {
      console.log(`  ✅ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ [FAIL] ${testName}`);
      throw new Error(`Test failed: ${testName}`);
    }
  }

  // Test 1: Token cannot leave yard with roll 1..5
  const tokens = createMockTokens();
  for (let roll = 1; roll <= 5; roll++) {
    const res = canMoveToken(tokens.red[0], roll, tokens);
    assert(!res.canMove, `Token in yard cannot move with roll ${roll}`);
  }

  // Test 2: Token can leave yard with roll 6
  const roll6Res = canMoveToken(tokens.red[0], 6, tokens);
  assert(roll6Res.canMove && roll6Res.targetStep === 0, 'Token in yard leaves to step 0 with roll 6');

  // Test 3: Token moves exact number of steps rolled
  tokens.red[0].stepIndex = 10;
  const moveRes = canMoveToken(tokens.red[0], 4, tokens);
  assert(moveRes.canMove && moveRes.targetStep === 14, 'Token at step 10 moves to step 14 with roll 4');

  // Test 4: Cannot overshoot final home position (MAX_STEP = 56)
  tokens.red[0].stepIndex = 54;
  const overshootRes = canMoveToken(tokens.red[0], 3, tokens); // 54 + 3 = 57 > 56
  assert(!overshootRes.canMove, 'Token at step 54 cannot move with roll 3 (overshoot)');

  // Test 5: Exact landing at 56 finishes token
  const finishRes = canMoveToken(tokens.red[0], 2, tokens); // 54 + 2 = 56
  assert(finishRes.canMove && finishRes.willFinish, 'Token at step 54 finishes with exact roll 2');

  // Test 6: Safe squares prevent capture
  // Red start square (step 0 for Red, track index 0) is safe
  assert(isSafePosition('red', 0), 'Red starting square (step 0) is safe');
  assert(isSafePosition('blue', 0), 'Blue starting square is safe');

  // Test 7: Vulnerable capture
  // Red start is track 0. Green start is track 39.
  // Suppose Red token is at step 10 (track index 10).
  // Suppose Blue token moves to track index 10.
  // Blue start is 13. To land on 10, (13 + progress) % 52 = 10 => progress = 49.
  const captureTokens = createMockTokens();
  captureTokens.red[0].stepIndex = 10; // Red token at track index 10
  captureTokens.blue[0].stepIndex = 45; // Blue at step 45. Roll 4 -> step 49.
  // Verify blue track index at step 49: (13 + 49) % 52 = 62 % 52 = 10!
  assert(getTrackIndexForPlayer('blue', 49) === 10, 'Blue step 49 maps to track index 10');
  assert(getTrackIndexForPlayer('red', 10) === 10, 'Red step 10 maps to track index 10');

  const execCapture = executeMove('blue', 0, 4, captureTokens, defaultSettings, 0);
  assert(
    execCapture.capturedToken !== null &&
    execCapture.capturedToken.color === 'red' &&
    execCapture.capturedToken.id === 0,
    'Blue captures Red token on vulnerable square 10'
  );
  assert(execCapture.nextTokens.red[0].stepIndex === -1, 'Captured Red token is reset to home yard (-1)');
  assert(execCapture.grantBonusTurn, 'Capture grants a bonus turn');

  // Test 8: Rolling a 6 grants bonus turn
  const execSix = executeMove('red', 1, 6, captureTokens, defaultSettings, 1);
  assert(execSix.grantBonusTurn, 'Rolling 6 grants bonus turn');

  // Test 9: 3 consecutive sixes penalty
  const execThreeSixes = executeMove('red', 1, 6, captureTokens, defaultSettings, 3);
  assert(!execThreeSixes.grantBonusTurn, '3 consecutive sixes forfeit bonus turn');

  // Test 10: Win condition logic
  const winTokens = createMockTokens();
  assert(!hasPlayerWon(winTokens.red, false), 'No win when 0 tokens home');
  winTokens.red[0].isFinished = true;
  winTokens.red[1].isFinished = true;
  assert(hasPlayerWon(winTokens.red, true), 'Quick mode wins with 2 tokens home');
  assert(!hasPlayerWon(winTokens.red, false), 'Standard mode requires 4 tokens to win');
  winTokens.red[2].isFinished = true;
  winTokens.red[3].isFinished = true;
  assert(hasPlayerWon(winTokens.red, false), 'Standard mode wins with 4 tokens home');

  console.log(`\n🎉 All ${passed}/${total} automated tests passed successfully!`);
}

runTests();
