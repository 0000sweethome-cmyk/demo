/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import {
  createLudoBoardTexture,
  createWoodTableTexture,
  createContactShadowTexture,
} from './Materials';
import {
  BOARD_SIZE,
  CELL_SIZE,
  BOARD_SURFACE_Y,
  SAFE_TRACK_INDICES,
  COMMON_TRACK_COORDS,
  gridToWorld,
} from '../game/BoardCoordinates';

export class Board3D {
  public group: THREE.Group;
  private boardTexture: THREE.CanvasTexture | null = null;
  private tableTexture: THREE.CanvasTexture | null = null;
  private shadowTexture: THREE.CanvasTexture | null = null;

  // Animated 3D center finish rosette & crown
  private centerCrown: THREE.Group | null = null;
  private safeStarMeshes: THREE.Mesh[] = [];

  constructor(anisotropy = 4) {
    this.group = new THREE.Group();
    this.group.name = 'LudoBoard';

    this.buildTable(anisotropy);
    this.buildBoard(anisotropy);
    this.buildSafeStars();
    this.buildCenterpiece();
  }

  private buildTable(anisotropy: number) {
    this.tableTexture = createWoodTableTexture();
    this.tableTexture.anisotropy = anisotropy;

    const tableGeo = new THREE.PlaneGeometry(36, 36);
    const tableMat = new THREE.MeshStandardMaterial({
      map: this.tableTexture,
      roughness: 0.55,
      metalness: 0.12,
    });

    const tableMesh = new THREE.Mesh(tableGeo, tableMat);
    tableMesh.rotation.x = -Math.PI / 2;
    tableMesh.position.y = -0.01;
    tableMesh.receiveShadow = true;
    this.group.add(tableMesh);

    // Board Drop Shadow
    this.shadowTexture = createContactShadowTexture();
    const shadowGeo = new THREE.PlaneGeometry(14.8, 14.8);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: this.shadowTexture,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.005;
    this.group.add(shadowMesh);
  }

  private buildBoard(anisotropy: number) {
    const boardDimension = BOARD_SIZE * CELL_SIZE; // 12.0 units
    const boardThickness = 0.5;
    const borderPadding = 0.5;
    const totalSize = boardDimension + borderPadding * 2; // 13.0 units

    // 1. Solid Mahogany Wood Frame / Body
    const frameGeo = new THREE.BoxGeometry(totalSize, boardThickness, totalSize);
    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x3e2016, // dark mahogany
      roughness: 0.35,
      metalness: 0.15,
    });
    const frameMesh = new THREE.Mesh(frameGeo, frameMat);
    frameMesh.position.y = boardThickness / 2;
    frameMesh.castShadow = true;
    frameMesh.receiveShadow = true;
    this.group.add(frameMesh);

    // 2. Gold Brass Inlay Border & Corner Brackets with Rivets
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37, // polished gold brass
      roughness: 0.22,
      metalness: 0.88,
    });

    const screwMat = new THREE.MeshStandardMaterial({
      color: 0x222222,
      roughness: 0.3,
      metalness: 0.8,
    });

    const bracketSize = 0.75;
    const bracketThickness = 0.025;
    const cornerOffset = totalSize / 2 - bracketSize / 2;
    const bracketGeo = new THREE.BoxGeometry(bracketSize, bracketThickness, bracketSize);
    const screwGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.015, 8);

    const corners = [
      { x: -cornerOffset, z: -cornerOffset },
      { x: cornerOffset, z: -cornerOffset },
      { x: -cornerOffset, z: cornerOffset },
      { x: cornerOffset, z: cornerOffset },
    ];

    corners.forEach((c) => {
      const bracket = new THREE.Mesh(bracketGeo, goldMat);
      bracket.position.set(c.x, boardThickness + 0.005, c.z);
      bracket.castShadow = true;
      this.group.add(bracket);

      // Add 4 brass rivet screws to each corner bracket
      const d = 0.22;
      const screwOffsets = [
        { x: -d, z: -d },
        { x: d, z: -d },
        { x: -d, z: d },
        { x: d, z: d },
      ];
      screwOffsets.forEach((so) => {
        const screw = new THREE.Mesh(screwGeo, screwMat);
        screw.position.set(c.x + so.x, boardThickness + 0.018, c.z + so.z);
        this.group.add(screw);
      });
    });

    // 3. Printed Ludo Board Surface Plate
    this.boardTexture = createLudoBoardTexture();
    this.boardTexture.anisotropy = anisotropy;

    const surfaceGeo = new THREE.PlaneGeometry(boardDimension, boardDimension);
    const surfaceMat = new THREE.MeshStandardMaterial({
      map: this.boardTexture,
      roughness: 0.25,
      metalness: 0.08,
    });

    const surfaceMesh = new THREE.Mesh(surfaceGeo, surfaceMat);
    surfaceMesh.rotation.x = -Math.PI / 2;
    surfaceMesh.position.y = boardThickness + 0.002;
    surfaceMesh.receiveShadow = true;
    this.group.add(surfaceMesh);

    // 4. Subtle Beveled Outer Trim Strip
    const trimHeight = 0.06;
    const trimWidth = 0.12;
    const trimGeoH = new THREE.BoxGeometry(boardDimension + 0.24, trimHeight, trimWidth);
    const trimGeoV = new THREE.BoxGeometry(trimWidth, trimHeight, boardDimension + 0.24);
    const trimMat = goldMat;

    const halfD = boardDimension / 2 + trimWidth / 2;
    const trimTop = new THREE.Mesh(trimGeoH, trimMat);
    trimTop.position.set(0, boardThickness + trimHeight / 2, -halfD);
    const trimBottom = new THREE.Mesh(trimGeoH, trimMat);
    trimBottom.position.set(0, boardThickness + trimHeight / 2, halfD);
    const trimLeft = new THREE.Mesh(trimGeoV, trimMat);
    trimLeft.position.set(-halfD, boardThickness + trimHeight / 2, 0);
    const trimRight = new THREE.Mesh(trimGeoV, trimMat);
    trimRight.position.set(halfD, boardThickness + trimHeight / 2, 0);

    this.group.add(trimTop, trimBottom, trimLeft, trimRight);
  }

  /**
   * Builds extruded 3D gold star medallions on the 8 safe squares.
   */
  private buildSafeStars() {
    const starShape = new THREE.Shape();
    const spikes = 5;
    const outerR = 0.16;
    const innerR = 0.07;
    let rot = (Math.PI / 2) * 3;
    let x = 0;
    let y = 0;
    const step = Math.PI / spikes;

    starShape.moveTo(0, -outerR);
    for (let i = 0; i < spikes; i++) {
      x = Math.cos(rot) * outerR;
      y = Math.sin(rot) * outerR;
      starShape.lineTo(x, y);
      rot += step;

      x = Math.cos(rot) * innerR;
      y = Math.sin(rot) * innerR;
      starShape.lineTo(x, y);
      rot += step;
    }
    starShape.closePath();

    const starGeo = new THREE.ExtrudeGeometry(starShape, {
      depth: 0.015,
      bevelEnabled: true,
      bevelThickness: 0.005,
      bevelSize: 0.005,
      bevelSegments: 2,
    });

    const starMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      metalness: 0.9,
      roughness: 0.2,
      emissive: 0xffaa00,
      emissiveIntensity: 0.25,
    });

    SAFE_TRACK_INDICES.forEach((trackIdx) => {
      const coord = COMMON_TRACK_COORDS[trackIdx];
      const worldPos = gridToWorld(coord.x, coord.y);

      const starMesh = new THREE.Mesh(starGeo, starMat);
      starMesh.rotation.x = Math.PI / 2;
      starMesh.position.set(worldPos.x, BOARD_SURFACE_Y + 0.004, worldPos.z);
      this.group.add(starMesh);
      this.safeStarMeshes.push(starMesh);
    });
  }

  /**
   * Builds an imperial 3D gold crown centerpiece in the middle of the board.
   */
  private buildCenterpiece() {
    this.centerCrown = new THREE.Group();
    this.centerCrown.position.set(0, BOARD_SURFACE_Y + 0.02, 0);

    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      metalness: 0.95,
      roughness: 0.15,
      emissive: 0xb8860b,
      emissiveIntensity: 0.2,
    });

    const rubyMat = new THREE.MeshStandardMaterial({
      color: 0xe53935,
      metalness: 0.2,
      roughness: 0.1,
      emissive: 0x880e4f,
      emissiveIntensity: 0.4,
    });

    // Circular base ring
    const baseGeo = new THREE.TorusGeometry(0.35, 0.04, 12, 32);
    const baseMesh = new THREE.Mesh(baseGeo, goldMat);
    baseMesh.rotation.x = Math.PI / 2;
    this.centerCrown.add(baseMesh);

    // 5 Crown Spikes
    for (let i = 0; i < 5; i++) {
      const angle = (i * Math.PI * 2) / 5;
      const spikeX = Math.cos(angle) * 0.35;
      const spikeZ = Math.sin(angle) * 0.35;

      const coneGeo = new THREE.ConeGeometry(0.045, 0.18, 8);
      const coneMesh = new THREE.Mesh(coneGeo, goldMat);
      coneMesh.position.set(spikeX, 0.1, spikeZ);
      this.centerCrown.add(coneMesh);

      // Little ruby jewel on tip of spike
      const gemGeo = new THREE.OctahedronGeometry(0.025, 0);
      const gemMesh = new THREE.Mesh(gemGeo, rubyMat);
      gemMesh.position.set(spikeX, 0.2, spikeZ);
      this.centerCrown.add(gemMesh);
    }

    // Central Floating Grand Diamond
    const diamondGeo = new THREE.OctahedronGeometry(0.1, 0);
    const diamondMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.05,
      metalness: 0.95,
      emissive: 0x4fc3f7,
      emissiveIntensity: 0.4,
    });
    const diamondMesh = new THREE.Mesh(diamondGeo, diamondMat);
    diamondMesh.position.y = 0.14;
    diamondMesh.name = 'CrownDiamond';
    this.centerCrown.add(diamondMesh);

    this.group.add(this.centerCrown);
  }

  public update(_delta: number, elapsed: number) {
    if (this.centerCrown) {
      this.centerCrown.rotation.y = elapsed * 0.4;
      const diamond = this.centerCrown.getObjectByName('CrownDiamond');
      if (diamond) {
        diamond.rotation.y = elapsed * 1.5;
        diamond.position.y = 0.14 + Math.sin(elapsed * 2.5) * 0.03;
      }
    }
  }

  public dispose() {
    this.boardTexture?.dispose();
    this.tableTexture?.dispose();
    this.shadowTexture?.dispose();

    this.group.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.geometry.dispose();
        if (Array.isArray(child.material)) {
          child.material.forEach((m) => m.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
  }
}
