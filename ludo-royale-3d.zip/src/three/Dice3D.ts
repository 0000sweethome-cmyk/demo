/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { BOARD_SURFACE_Y } from '../game/BoardCoordinates';
import { createContactShadowTexture } from './Materials';

export class Dice3D {
  public group: THREE.Group;
  private diceMesh: THREE.Mesh;
  private shadowMesh: THREE.Mesh;

  public isRolling = false;
  private currentResult = 6;

  // Animation variables
  private rollProgress = 0;
  private rollDuration = 0.85;
  private startPosition = new THREE.Vector3();
  private targetPosition = new THREE.Vector3();
  private startRotation = new THREE.Euler();
  private targetEuler = new THREE.Euler();
  private spinRevolutions = new THREE.Vector3();
  private onRollFinish?: (result: number) => void;
  private onBounceSound?: () => void;
  private hasPlayedBounce = false;

  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'Dice3D';

    const diceSize = 0.72;

    // Build 6 Face Textures:
    // Index 0: +X = Face 2
    // Index 1: -X = Face 5
    // Index 2: +Y = Face 1
    // Index 3: -Y = Face 6
    // Index 4: +Z = Face 3
    // Index 5: -Z = Face 4
    const faceNumbers = [2, 5, 1, 6, 3, 4];
    const materials = faceNumbers.map((num) => {
      const tex = this.createDiceFaceTexture(num);
      return new THREE.MeshStandardMaterial({
        map: tex,
        roughness: 0.22,
        metalness: 0.08,
      });
    });

    const diceGeo = new THREE.BoxGeometry(diceSize, diceSize, diceSize);
    this.diceMesh = new THREE.Mesh(diceGeo, materials);
    this.diceMesh.castShadow = true;
    this.diceMesh.receiveShadow = true;
    this.diceMesh.position.y = diceSize / 2;
    this.group.add(this.diceMesh);

    // Contact shadow
    const shadowTex = createContactShadowTexture();
    const shadowGeo = new THREE.PlaneGeometry(1.2, 1.2);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
    });
    this.shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    this.shadowMesh.rotation.x = -Math.PI / 2;
    this.shadowMesh.position.y = 0.005;
    this.group.add(this.shadowMesh);

    // Initial resting position in center board or tray
    this.group.position.set(0, BOARD_SURFACE_Y, 0);
    this.setFaceUp(6);
  }

  /**
   * Generates crisp 256x256 canvas texture for a dice face with rounded borders and pips.
   */
  private createDiceFaceTexture(value: number): THREE.CanvasTexture {
    const size = 256;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    // Ivory/creamy rounded background
    ctx.fillStyle = '#f8f6f0';
    ctx.fillRect(0, 0, size, size);

    // Subtle edge bevel shading
    const grad = ctx.createRadialGradient(size / 2, size / 2, size * 0.3, size / 2, size / 2, size * 0.7);
    grad.addColorStop(0, 'rgba(255,255,255,0.8)');
    grad.addColorStop(1, 'rgba(220,215,205,0.6)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);

    // Inner subtle rounded frame
    ctx.strokeStyle = '#e0dad0';
    ctx.lineWidth = 12;
    ctx.strokeRect(6, 6, size - 12, size - 12);

    // Pip coordinates
    const pipRadius = 20;
    const pipColor = '#1c1b18';

    const drawPip = (cx: number, cy: number) => {
      ctx.save();
      ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
      ctx.shadowBlur = 4;
      ctx.fillStyle = pipColor;
      ctx.beginPath();
      ctx.arc(cx, cy, pipRadius, 0, Math.PI * 2);
      ctx.fill();

      // Small specular reflection on pip
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.beginPath();
      ctx.arc(cx - 5, cy - 5, pipRadius * 0.35, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    const mid = size / 2;
    const l = size * 0.28;
    const r = size * 0.72;
    const t = size * 0.28;
    const b = size * 0.72;

    switch (value) {
      case 1:
        drawPip(mid, mid);
        break;
      case 2:
        drawPip(l, t);
        drawPip(r, b);
        break;
      case 3:
        drawPip(l, t);
        drawPip(mid, mid);
        drawPip(r, b);
        break;
      case 4:
        drawPip(l, t);
        drawPip(r, t);
        drawPip(l, b);
        drawPip(r, b);
        break;
      case 5:
        drawPip(l, t);
        drawPip(r, t);
        drawPip(mid, mid);
        drawPip(l, b);
        drawPip(r, b);
        break;
      case 6:
        drawPip(l, t);
        drawPip(r, t);
        drawPip(l, mid);
        drawPip(r, mid);
        drawPip(l, b);
        drawPip(r, b);
        break;
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  /**
   * Sets target face immediately facing up (+Y).
   */
  public setFaceUp(value: number) {
    this.currentResult = value;
    const euler = this.getTargetEulerForValue(value);
    this.diceMesh.rotation.copy(euler);
  }

  /**
   * Calculates the exact Euler rotation required to make the pip `value` face upward (+Y).
   */
  private getTargetEulerForValue(value: number): THREE.Euler {
    switch (value) {
      case 1: // Face 1 is +Y
        return new THREE.Euler(0, 0, 0);
      case 6: // Face 6 is -Y
        return new THREE.Euler(Math.PI, 0, 0);
      case 2: // Face 2 is +X
        return new THREE.Euler(0, 0, Math.PI / 2);
      case 5: // Face 5 is -X
        return new THREE.Euler(0, 0, -Math.PI / 2);
      case 3: // Face 3 is +Z
        return new THREE.Euler(-Math.PI / 2, 0, 0);
      case 4: // Face 4 is -Z
        return new THREE.Euler(Math.PI / 2, 0, 0);
      default:
        return new THREE.Euler(0, 0, 0);
    }
  }

  /**
   * Launches physical roll animation settling reliably on `targetValue`.
   */
  public rollTo(
    targetValue: number,
    targetWorldPos?: THREE.Vector3,
    onFinish?: (res: number) => void,
    onBounce?: () => void
  ) {
    if (this.isRolling) return;

    this.isRolling = true;
    this.currentResult = targetValue;
    this.onRollFinish = onFinish;
    this.onBounceSound = onBounce;
    this.hasPlayedBounce = false;
    this.rollProgress = 0;
    this.rollDuration = 0.85;

    this.startPosition.copy(this.group.position);
    this.targetPosition.copy(targetWorldPos || new THREE.Vector3(0, BOARD_SURFACE_Y, 0));

    this.startRotation.copy(this.diceMesh.rotation);
    this.targetEuler = this.getTargetEulerForValue(targetValue);

    // Number of full 360 degree tumbling revolutions along each axis
    this.spinRevolutions.set(
      (Math.floor(Math.random() * 2) + 2) * Math.PI * 2,
      (Math.floor(Math.random() * 2) + 2) * Math.PI * 2,
      (Math.floor(Math.random() * 2) + 2) * Math.PI * 2
    );
  }

  public update(delta: number) {
    if (!this.isRolling) return;

    this.rollProgress += delta / this.rollDuration;

    if (this.rollProgress >= 1.0) {
      this.rollProgress = 1.0;
      this.isRolling = false;

      // Final rest state
      this.group.position.copy(this.targetPosition);
      this.diceMesh.rotation.copy(this.targetEuler);
      this.shadowMesh.scale.set(1, 1, 1);
      (this.shadowMesh.material as THREE.MeshBasicMaterial).opacity = 0.6;

      if (!this.hasPlayedBounce) {
        this.onBounceSound?.();
        this.hasPlayedBounce = true;
      }

      this.onRollFinish?.(this.currentResult);
      return;
    }

    const t = this.rollProgress;

    // Cubic ease-out for settling
    const easeOut = 1 - Math.pow(1 - t, 3);

    // Position interpolation (drift from start to target)
    this.group.position.x = THREE.MathUtils.lerp(this.startPosition.x, this.targetPosition.x, easeOut);
    this.group.position.z = THREE.MathUtils.lerp(this.startPosition.z, this.targetPosition.z, easeOut);

    // Bouncing parabolic arc on Y with secondary small bounce
    let bounceY = 0;
    if (t < 0.75) {
      // Main toss arc
      const arcT = t / 0.75;
      bounceY = Math.sin(arcT * Math.PI) * 1.5;
    } else {
      // Settling bounce
      if (!this.hasPlayedBounce) {
        this.onBounceSound?.();
        this.hasPlayedBounce = true;
      }
      const arcT = (t - 0.75) / 0.25;
      bounceY = Math.sin(arcT * Math.PI) * 0.25;
    }

    this.group.position.y = this.targetPosition.y + bounceY;

    // Contact shadow scaling
    const shadowScale = Math.max(0.4, 1.0 - bounceY * 0.35);
    this.shadowMesh.scale.set(shadowScale, shadowScale, shadowScale);
    (this.shadowMesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0.2, 0.6 - bounceY * 0.25);

    // Multi-axis rotation tumble settling cleanly into targetEuler
    const rotT = easeOut;
    this.diceMesh.rotation.x = this.targetEuler.x + (1 - rotT) * this.spinRevolutions.x;
    this.diceMesh.rotation.y = this.targetEuler.y + (1 - rotT) * this.spinRevolutions.y;
    this.diceMesh.rotation.z = this.targetEuler.z + (1 - rotT) * this.spinRevolutions.z;
  }

  public dispose() {
    this.diceMesh.geometry.dispose();
    if (Array.isArray(this.diceMesh.material)) {
      this.diceMesh.material.forEach((m) => {
        if (m instanceof THREE.MeshStandardMaterial && m.map) m.map.dispose();
        m.dispose();
      });
    }
    this.shadowMesh.geometry.dispose();
    (this.shadowMesh.material as THREE.Material).dispose();
  }
}
