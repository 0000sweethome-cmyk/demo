/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { BOARD_SURFACE_Y, gridToWorld, COMMON_TRACK_COORDS, COLOR_HOME_LANES, getTrackIndexForPlayer } from '../game/BoardCoordinates';
import { PlayerColor } from '../game/types';
import { PLAYER_HEX_NUMBERS } from './Materials';

export interface Particle {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  rotVelocity: THREE.Vector3;
  life: number;
  maxLife: number;
  color: number;
}

export class VisualEffects {
  public group: THREE.Group;
  private particles: Particle[] = [];
  private shockwaves: { mesh: THREE.Mesh; life: number; maxLife: number; maxRadius: number }[] = [];

  // Path Preview Line / Dots
  private pathDots: THREE.Mesh[] = [];
  private targetMarker: THREE.Group;
  private targetCrosshairRing: THREE.Mesh;

  // Floating hover arrow
  public hoverArrow: THREE.Group;

  // Reusable geometries and materials to avoid GC
  private particleGeo: THREE.DodecahedronGeometry;
  private sparkGeo: THREE.BoxGeometry;
  private shockwaveGeo: THREE.RingGeometry;

  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'VisualEffects';

    this.particleGeo = new THREE.DodecahedronGeometry(0.08, 0);
    this.sparkGeo = new THREE.BoxGeometry(0.06, 0.06, 0.12);
    this.shockwaveGeo = new THREE.RingGeometry(0.1, 0.2, 32);

    // Build target crosshair / kill indicator
    this.targetMarker = new THREE.Group();
    this.targetMarker.visible = false;

    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xff1744,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85,
      depthWrite: false,
    });
    this.targetCrosshairRing = new THREE.Mesh(new THREE.RingGeometry(0.32, 0.42, 32), ringMat);
    this.targetCrosshairRing.rotation.x = -Math.PI / 2;
    this.targetMarker.add(this.targetCrosshairRing);

    // 4 Crosshair teeth
    const toothGeo = new THREE.BoxGeometry(0.06, 0.02, 0.24);
    const toothMat = new THREE.MeshBasicMaterial({ color: 0xff1744 });
    for (let i = 0; i < 4; i++) {
      const tooth = new THREE.Mesh(toothGeo, toothMat);
      tooth.rotation.y = (i * Math.PI) / 2;
      tooth.position.set(
        Math.cos((i * Math.PI) / 2) * 0.44,
        0.005,
        Math.sin((i * Math.PI) / 2) * 0.44
      );
      this.targetMarker.add(tooth);
    }
    this.group.add(this.targetMarker);

    // Build floating hover chevron
    this.hoverArrow = new THREE.Group();
    this.hoverArrow.visible = false;
    const arrowConeGeo = new THREE.ConeGeometry(0.14, 0.28, 16);
    arrowConeGeo.rotateX(Math.PI); // point downwards
    const arrowMat = new THREE.MeshStandardMaterial({
      color: 0xffd54f,
      metalness: 0.8,
      roughness: 0.2,
      emissive: 0xffb300,
      emissiveIntensity: 0.4,
    });
    const arrowMesh = new THREE.Mesh(arrowConeGeo, arrowMat);
    this.hoverArrow.add(arrowMesh);
    this.group.add(this.hoverArrow);

    // Pre-create 12 path preview dot meshes
    const dotGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.02, 16);
    for (let i = 0; i < 12; i++) {
      const dotMat = new THREE.MeshBasicMaterial({
        color: 0xffeb3b,
        transparent: true,
        opacity: 0.8,
        depthWrite: false,
      });
      const dotMesh = new THREE.Mesh(dotGeo, dotMat);
      dotMesh.visible = false;
      this.pathDots.push(dotMesh);
      this.group.add(dotMesh);
    }
  }

  /**
   * Spawns explosive 3D debris and sparks when a token is captured/killed.
   */
  public spawnKillExplosion(worldPos: THREE.Vector3, victimColor: PlayerColor) {
    const hexColor = PLAYER_HEX_NUMBERS[victimColor];
    const particleCount = 28;

    // 1. Expanding Shockwave Ring
    const shockMat = new THREE.MeshBasicMaterial({
      color: hexColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
    });
    const shockMesh = new THREE.Mesh(this.shockwaveGeo, shockMat);
    shockMesh.rotation.x = -Math.PI / 2;
    shockMesh.position.set(worldPos.x, BOARD_SURFACE_Y + 0.015, worldPos.z);
    this.group.add(shockMesh);
    this.shockwaves.push({
      mesh: shockMesh,
      life: 0,
      maxLife: 0.45,
      maxRadius: 1.8,
    });

    // 2. 3D Shatter Debris & Golden Sparks
    for (let i = 0; i < particleCount; i++) {
      const isGold = i % 3 === 0;
      const col = isGold ? 0xffd700 : hexColor;
      const mat = new THREE.MeshStandardMaterial({
        color: col,
        roughness: 0.2,
        metalness: isGold ? 0.9 : 0.4,
        emissive: col,
        emissiveIntensity: 0.5,
      });

      const mesh = new THREE.Mesh(isGold ? this.sparkGeo : this.particleGeo, mat);
      mesh.position.set(
        worldPos.x + (Math.random() - 0.5) * 0.1,
        worldPos.y + 0.35 + (Math.random() - 0.5) * 0.1,
        worldPos.z + (Math.random() - 0.5) * 0.1
      );

      // Explosive conical upward velocity
      const angle = Math.random() * Math.PI * 2;
      const speed = 2.5 + Math.random() * 3.5;
      const upward = 3.0 + Math.random() * 4.0;

      const velocity = new THREE.Vector3(
        Math.cos(angle) * speed,
        upward,
        Math.sin(angle) * speed
      );

      const rotVelocity = new THREE.Vector3(
        (Math.random() - 0.5) * 15,
        (Math.random() - 0.5) * 15,
        (Math.random() - 0.5) * 15
      );

      this.group.add(mesh);
      this.particles.push({
        mesh,
        velocity,
        rotVelocity,
        life: 0,
        maxLife: 0.65 + Math.random() * 0.35,
        color: col,
      });
    }
  }

  /**
   * Shows a preview trail of steps from currentStep to targetStep.
   */
  public showPathPreview(color: PlayerColor, currentStep: number, targetStep: number, isKill: boolean) {
    this.hidePathPreview();

    const steps: { x: number; y: number; z: number }[] = [];
    if (currentStep === -1) {
      // Exiting yard to start square (step 0)
      const trackIdx = getTrackIndexForPlayer(color, 0);
      const coord = COMMON_TRACK_COORDS[trackIdx];
      steps.push(gridToWorld(coord.x, coord.y));
    } else {
      for (let s = currentStep + 1; s <= targetStep; s++) {
        if (s <= 50) {
          const trackIdx = getTrackIndexForPlayer(color, s);
          const coord = COMMON_TRACK_COORDS[trackIdx];
          steps.push(gridToWorld(coord.x, coord.y));
        } else {
          const laneIdx = Math.min(s - 51, COLOR_HOME_LANES[color].length - 1);
          const coord = COLOR_HOME_LANES[color][laneIdx];
          steps.push(gridToWorld(coord.x, coord.y));
        }
      }
    }

    // Place path dots
    steps.forEach((pos, idx) => {
      if (idx < this.pathDots.length) {
        const dot = this.pathDots[idx];
        dot.position.set(pos.x, BOARD_SURFACE_Y + 0.015, pos.z);
        dot.visible = true;
        const mat = dot.material as THREE.MeshBasicMaterial;
        mat.color.setHex(idx === steps.length - 1 && isKill ? 0xff1744 : 0xffeb3b);
      }
    });

    // If this move results in a kill/capture, place target crosshair on destination
    if (isKill && steps.length > 0) {
      const dest = steps[steps.length - 1];
      this.targetMarker.position.set(dest.x, BOARD_SURFACE_Y + 0.02, dest.z);
      this.targetMarker.visible = true;
    }
  }

  public hidePathPreview() {
    this.pathDots.forEach((d) => (d.visible = false));
    this.targetMarker.visible = false;
  }

  public setHoverChevron(worldPos: THREE.Vector3 | null) {
    if (!worldPos) {
      this.hoverArrow.visible = false;
    } else {
      this.hoverArrow.position.set(worldPos.x, worldPos.y + 0.95, worldPos.z);
      this.hoverArrow.visible = true;
    }
  }

  public update(delta: number, elapsed: number) {
    // 1. Update Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += delta;

      if (p.life >= p.maxLife) {
        this.group.remove(p.mesh);
        p.mesh.geometry.dispose();
        (p.mesh.material as THREE.Material).dispose();
        this.particles.splice(i, 1);
        continue;
      }

      // Physics: Apply gravity and velocity
      p.velocity.y -= 9.8 * delta;
      p.mesh.position.x += p.velocity.x * delta;
      p.mesh.position.y += p.velocity.y * delta;
      p.mesh.position.z += p.velocity.z * delta;

      // Rotation
      p.mesh.rotation.x += p.rotVelocity.x * delta;
      p.mesh.rotation.y += p.rotVelocity.y * delta;
      p.mesh.rotation.z += p.rotVelocity.z * delta;

      // Ground bounce
      if (p.mesh.position.y < BOARD_SURFACE_Y + 0.04) {
        p.mesh.position.y = BOARD_SURFACE_Y + 0.04;
        p.velocity.y = -p.velocity.y * 0.45;
        p.velocity.x *= 0.7;
        p.velocity.z *= 0.7;
      }

      // Fade out
      const progress = p.life / p.maxLife;
      const scale = Math.max(0.01, 1 - progress);
      p.mesh.scale.set(scale, scale, scale);
    }

    // 2. Update Shockwaves
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.life += delta;

      if (sw.life >= sw.maxLife) {
        this.group.remove(sw.mesh);
        (sw.mesh.material as THREE.Material).dispose();
        this.shockwaves.splice(i, 1);
        continue;
      }

      const t = sw.life / sw.maxLife;
      const currentRadius = THREE.MathUtils.lerp(0.3, sw.maxRadius, t);
      sw.mesh.scale.set(currentRadius, currentRadius, currentRadius);

      const mat = sw.mesh.material as THREE.MeshBasicMaterial;
      mat.opacity = (1 - t) * 0.9;
    }

    // 3. Animate hover chevron bobbing
    if (this.hoverArrow.visible) {
      this.hoverArrow.rotation.y = elapsed * 3;
      this.hoverArrow.position.y += Math.sin(elapsed * 6) * 0.003;
    }

    // 4. Animate target crosshair spinning
    if (this.targetMarker.visible) {
      this.targetCrosshairRing.rotation.z = elapsed * 2.5;
      const pulse = 1 + Math.sin(elapsed * 8) * 0.08;
      this.targetMarker.scale.set(pulse, 1, pulse);
    }
  }

  public dispose() {
    this.particles.forEach((p) => {
      this.group.remove(p.mesh);
      p.mesh.geometry.dispose();
      (p.mesh.material as THREE.Material).dispose();
    });
    this.particles = [];

    this.shockwaves.forEach((sw) => {
      this.group.remove(sw.mesh);
      (sw.mesh.material as THREE.Material).dispose();
    });
    this.shockwaves = [];

    this.particleGeo.dispose();
    this.sparkGeo.dispose();
    this.shockwaveGeo.dispose();
  }
}
