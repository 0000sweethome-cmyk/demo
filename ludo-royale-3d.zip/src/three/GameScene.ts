/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Board3D } from './Board3D';
import { Token3D } from './Token3D';
import { Dice3D } from './Dice3D';
import { VisualEffects } from './Effects';
import { audioManager } from '../audio/AudioManager';
import { PlayerColor, CameraViewMode, TokenState } from '../game/types';
import { BOARD_SURFACE_Y, COLOR_START_TRACK_INDEX, COMMON_TRACK_COORDS } from '../game/BoardCoordinates';

export interface SceneCallbacks {
  onTokenClicked: (color: PlayerColor, id: number) => void;
  onDiceClicked: () => void;
  onDiceRollComplete?: (result: number) => void;
  onDiceBounce?: () => void;
  onTokenHop?: (step: number) => void;
  onTokenHover?: (color: PlayerColor | null, id: number | null) => void;
}

export class GameScene {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  public container: HTMLElement;

  // Scene entities
  public board: Board3D;
  public dice: Dice3D;
  public tokens: Record<PlayerColor, Token3D[]>;
  public effects: VisualEffects;

  // Screen shake
  private screenShakeIntensity = 0;

  // Camera damping
  private currentCameraPos = new THREE.Vector3(0, 13, 12);
  private targetCameraPos = new THREE.Vector3(0, 13, 12);
  private currentLookAt = new THREE.Vector3(0, 0.5, 0);
  private targetLookAt = new THREE.Vector3(0, 0.5, 0);
  private viewMode: CameraViewMode = 'isometric';

  // Interaction & Raycasting
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  private callbacks: SceneCallbacks;
  private hoveredToken: Token3D | null = null;

  // Orbit controls / Manual dragging
  private isPointerDown = false;
  private pointerStartX = 0;
  private pointerStartY = 0;
  private cameraAzimuth = 0;
  private cameraPolar = 0.85; // radians from top
  private cameraRadius = 16;
  public allowManualRotation = true;

  // Lifecycle
  private isDisposed = false;
  private isSoftwareGl = false;
  private frameId = 0;
  private clock = new THREE.Clock();

  constructor(container: HTMLElement, callbacks: SceneCallbacks) {
    this.container = container;
    this.callbacks = callbacks;

    // 1. Detect Software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Setup Three.js Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth, container.clientHeight);

    container.appendChild(this.renderer.domElement);

    // 3. Scene & Fog
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x16141a); // deep warm charcoal room
    this.scene.fog = new THREE.FogExp2(0x16141a, 0.024);

    // 4. Camera
    this.camera = new THREE.PerspectiveCamera(
      42,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    this.updateCameraForAspect();

    // 5. Studio Environment Reflection Map
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 6. Studio Lighting Rig
    this.setupLighting();

    // 7. Add Board
    const maxAnisotropy = this.renderer.capabilities.getMaxAnisotropy();
    this.board = new Board3D(this.isSoftwareGl ? 1 : Math.min(maxAnisotropy, 8));
    this.scene.add(this.board.group);

    // 8. Add 3D Dice
    this.dice = new Dice3D();
    this.scene.add(this.dice.group);

    // 9. Add 16 3D Tokens
    this.tokens = {
      red: [0, 1, 2, 3].map((id) => new Token3D('red', id)),
      green: [0, 1, 2, 3].map((id) => new Token3D('green', id)),
      yellow: [0, 1, 2, 3].map((id) => new Token3D('yellow', id)),
      blue: [0, 1, 2, 3].map((id) => new Token3D('blue', id)),
    };

    (['red', 'green', 'yellow', 'blue'] as PlayerColor[]).forEach((col) => {
      this.tokens[col].forEach((tok) => this.scene.add(tok.group));
    });

    // 10. Add Visual Effects System (Debris, Shockwaves, Path Previews)
    this.effects = new VisualEffects();
    this.scene.add(this.effects.group);

    // 11. Bind Input Listeners
    this.setupEventListeners();

    // 11. Initial camera positioning
    this.setCameraPreset('isometric');

    // 12. Start Loop
    this.tick = this.tick.bind(this);
    this.tick();
  }

  private setupLighting() {
    // Warm Key Light with tight shadow bounds
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.2);
    keyLight.position.set(8, 18, 10);
    keyLight.castShadow = !this.isSoftwareGl;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.near = 5;
    keyLight.shadow.camera.far = 35;
    const d = 8.5;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0004;
    keyLight.shadow.normalBias = 0.02;
    this.scene.add(keyLight);

    // Cool Fill Light
    const fillLight = new THREE.DirectionalLight(0x90caf9, 0.7);
    fillLight.position.set(-10, 12, -8);
    this.scene.add(fillLight);

    // Soft Hemisphere Ambient Light (warm sky / ground bounce)
    const hemiLight = new THREE.HemisphereLight(0xfff8e1, 0x1b1724, 0.9);
    this.scene.add(hemiLight);
  }

  private updateCameraForAspect() {
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    const aspect = width / height;

    this.camera.aspect = aspect;

    // Responsive framing for smartphones:
    // Ensures the board is completely clear of the bottom dice info dock
    if (aspect < 1) {
      // Fit the board's 13-unit width plus generous margins
      const halfBoardExtent = 7.4;
      const halfFovRad = THREE.MathUtils.degToRad(22); // half of fov 44
      const distForWidth = halfBoardExtent / (Math.tan(halfFovRad) * Math.max(0.48, aspect));
      this.cameraRadius = Math.max(20, Math.min(29, distForWidth * 1.06));
      this.camera.fov = 44;

      // Shift camera framing upward by reserving bottom pixels for the dice dock
      const bottomDockReserve = Math.min(height * 0.24, 150);
      this.camera.setViewOffset(
        width,
        height + bottomDockReserve,
        0,
        bottomDockReserve,
        width,
        height
      );
    } else {
      this.cameraRadius = 16.5;
      this.camera.fov = 40;
      this.camera.clearViewOffset();
    }

    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.updateTargetCameraFromOrbit();
  }

  public setCameraPreset(mode: CameraViewMode, activeColor?: PlayerColor) {
    this.viewMode = mode;

    switch (mode) {
      case 'topdown':
        this.cameraPolar = 0.08;
        this.cameraAzimuth = 0;
        this.targetLookAt.set(0, 0.5, 0);
        break;

      case 'isometric':
        this.cameraPolar = 0.88;
        this.cameraAzimuth = 0;
        this.targetLookAt.set(0, 0.5, 0);
        break;

      case 'active_player':
        this.cameraPolar = 0.88;
        // Face active player's quadrant
        switch (activeColor) {
          case 'red':
            this.cameraAzimuth = Math.PI * 0.25;
            break;
          case 'blue':
            this.cameraAzimuth = -Math.PI * 0.25;
            break;
          case 'yellow':
            this.cameraAzimuth = -Math.PI * 0.75;
            break;
          case 'green':
            this.cameraAzimuth = Math.PI * 0.75;
            break;
          default:
            this.cameraAzimuth = 0;
        }
        this.targetLookAt.set(0, 0.5, 0);
        break;

      case 'free':
        // Keep current angles
        break;
    }

    this.updateTargetCameraFromOrbit();
  }

  private updateTargetCameraFromOrbit() {
    const sinP = Math.sin(this.cameraPolar);
    const cosP = Math.cos(this.cameraPolar);
    const sinA = Math.sin(this.cameraAzimuth);
    const cosA = Math.cos(this.cameraAzimuth);

    const x = this.cameraRadius * sinP * sinA;
    const y = this.cameraRadius * cosP;
    const z = this.cameraRadius * sinP * cosA;

    this.targetCameraPos.set(x, y, z);
  }

  private setupEventListeners() {
    const el = this.renderer.domElement;

    // Resize
    const handleResize = () => {
      if (this.isDisposed) return;
      this.updateCameraForAspect();
    };
    window.addEventListener('resize', handleResize);

    // Pointer events for raycast and orbit
    el.addEventListener('pointerdown', (e) => {
      this.isPointerDown = true;
      this.pointerStartX = e.clientX;
      this.pointerStartY = e.clientY;
    });

    el.addEventListener('pointermove', (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      if (this.isPointerDown && this.allowManualRotation) {
        const deltaX = e.clientX - this.pointerStartX;
        const deltaY = e.clientY - this.pointerStartY;

        // If dragged more than threshold, switch to manual orbit
        if (Math.abs(deltaX) > 4 || Math.abs(deltaY) > 4) {
          this.viewMode = 'free';
          this.cameraAzimuth -= deltaX * 0.006;
          this.cameraPolar = Math.max(0.12, Math.min(Math.PI / 2.1, this.cameraPolar - deltaY * 0.006));
          this.updateTargetCameraFromOrbit();
          this.pointerStartX = e.clientX;
          this.pointerStartY = e.clientY;
        }
      } else {
        // Hover raycast on tokens
        this.checkHover();
      }
    });

    el.addEventListener('pointerup', (e) => {
      const rect = el.getBoundingClientRect();
      const clickDist = Math.hypot(e.clientX - this.pointerStartX, e.clientY - this.pointerStartY);

      this.isPointerDown = false;

      // Only trigger click if pointer didn't drag
      if (clickDist < 8) {
        this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        this.handleClick();
      }
    });

    // Wheel zoom
    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraRadius = Math.max(8, Math.min(26, this.cameraRadius + e.deltaY * 0.015));
      this.updateTargetCameraFromOrbit();
    }, { passive: false });
  }

  private checkHover() {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    let foundToken: Token3D | null = null;
    let foundDice = false;

    for (const hit of intersects) {
      let obj: THREE.Object3D | null = hit.object;
      while (obj && obj !== this.scene) {
        if (obj.userData?.isToken) {
          const col = obj.userData.color as PlayerColor;
          const id = obj.userData.id as number;
          foundToken = this.tokens[col]?.[id] || null;
          break;
        }
        if (obj === this.dice.group) {
          foundDice = true;
          break;
        }
        obj = obj.parent;
      }
      if (foundToken || foundDice) break;
    }

    if (foundToken && foundToken.isSelectable) {
      this.container.style.cursor = 'pointer';
      this.hoveredToken = foundToken;
      this.effects.setHoverChevron(foundToken.group.position);
      this.callbacks.onTokenHover?.(foundToken.color, foundToken.id);
    } else if (foundDice && !this.dice.isRolling) {
      this.container.style.cursor = 'pointer';
      this.hoveredToken = null;
      this.effects.setHoverChevron(null);
      this.callbacks.onTokenHover?.(null, null);
    } else {
      this.container.style.cursor = 'default';
      this.hoveredToken = null;
      this.effects.setHoverChevron(null);
      this.callbacks.onTokenHover?.(null, null);
    }
  }

  private handleClick() {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    for (const hit of intersects) {
      let obj: THREE.Object3D | null = hit.object;
      while (obj && obj !== this.scene) {
        if (obj.userData?.isToken) {
          const col = obj.userData.color as PlayerColor;
          const id = obj.userData.id as number;
          const tok = this.tokens[col]?.[id];
          if (tok && tok.isSelectable) {
            this.callbacks.onTokenClicked(col, id);
            return;
          }
        }
        if (obj === this.dice.group) {
          if (!this.dice.isRolling) {
            this.callbacks.onDiceClicked();
            return;
          }
        }
        obj = obj.parent;
      }
    }
  }

  /**
   * Syncs token visual positions to match the authoritative game state.
   */
  public syncTokenStates(allTokens: Record<PlayerColor, TokenState[]>) {
    (['red', 'green', 'yellow', 'blue'] as PlayerColor[]).forEach((col) => {
      const states = allTokens[col];
      states.forEach((st) => {
        const tok3D = this.tokens[col][st.id];
        if (tok3D && !tok3D.isAnimating) {
          tok3D.snapToStep(st.stepIndex);
        }
      });
    });
  }

  /**
   * Updates which tokens have active selectable pulse glow.
   */
  public setSelectableTokens(selectableList: { color: PlayerColor; id: number }[]) {
    (['red', 'green', 'yellow', 'blue'] as PlayerColor[]).forEach((col) => {
      this.tokens[col].forEach((tok) => {
        const isSel = selectableList.some((s) => s.color === col && s.id === tok.id);
        tok.setSelectable(isSel);
      });
    });
  }

  /**
   * Animates a token moving smoothly through intermediate path steps.
   */
  public animateTokenMove(
    color: PlayerColor,
    tokenId: number,
    fromStep: number,
    toStep: number,
    speedMultiplier: number,
    onFinish?: () => void
  ) {
    const tok3D = this.tokens[color][tokenId];
    if (!tok3D) {
      onFinish?.();
      return;
    }

    const path: number[] = [];
    if (fromStep === -1) {
      // Exiting yard to starting step (0)
      path.push(0);
    } else {
      // Step-by-step track hops
      for (let s = fromStep + 1; s <= toStep; s++) {
        path.push(s);
      }
    }

    tok3D.animatePath(
      path,
      speedMultiplier,
      (step) => this.callbacks.onTokenHop?.(step),
      onFinish
    );
  }

  public triggerScreenShake(intensity: number) {
    this.screenShakeIntensity = Math.max(this.screenShakeIntensity, intensity);
  }

  /**
   * Dramatic Kill / Knockout sequence:
   * 1. Attacker slam stomp
   * 2. High impact screen shake & haptics
   * 3. 3D debris explosion & expanding shockwave
   * 4. Victim tumbling flight across the board with yard crash landing
   */
  public animateTokenCapture(
    victimColor: PlayerColor,
    victimTokenId: number,
    attackerColor?: PlayerColor,
    attackerTokenId?: number,
    onFinish?: () => void
  ) {
    const victim = this.tokens[victimColor]?.[victimTokenId];
    const attacker =
      attackerColor && attackerTokenId !== undefined
        ? this.tokens[attackerColor]?.[attackerTokenId]
        : null;

    if (!victim) {
      onFinish?.();
      return;
    }

    const impactPos = victim.group.position.clone();

    const runVictimKnockout = () => {
      // 1. Screen shake
      this.triggerScreenShake(0.44);

      // 2. 3D Explosive Debris & Expanding Shockwave
      this.effects.spawnKillExplosion(impactPos, victimColor);

      // 3. Mobile Device Vibration / Haptics
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([50, 40, 100]);
        } catch {}
      }

      // 4. Heavy Impact Audio & Ascending Whoosh
      audioManager.playHeavyKillImpact();
      audioManager.playWhooshFlight();

      // 5. Launch victim into high tumbling knockout arc
      victim.animateKillKnockout(
        () => {
          audioManager.playYardCrashLanding();
        },
        () => {
          onFinish?.();
        }
      );
    };

    if (attacker) {
      // Attacker executes a quick high stomp slam
      attacker.animateStomp(() => {
        runVictimKnockout();
      });
    } else {
      runVictimKnockout();
    }
  }

  /**
   * Rolls the 3D dice to land on pre-determined authoritative targetResult.
   */
  public rollDice(targetResult: number, activeColor: PlayerColor, onComplete?: (res: number) => void) {
    // Position dice in the center or slightly biased towards active quadrant
    let targetPos = new THREE.Vector3(0, BOARD_SURFACE_Y, 0);
    if (activeColor === 'red') targetPos = new THREE.Vector3(-1.2, BOARD_SURFACE_Y, 1.2);
    else if (activeColor === 'blue') targetPos = new THREE.Vector3(1.2, BOARD_SURFACE_Y, 1.2);
    else if (activeColor === 'yellow') targetPos = new THREE.Vector3(1.2, BOARD_SURFACE_Y, -1.2);
    else if (activeColor === 'green') targetPos = new THREE.Vector3(-1.2, BOARD_SURFACE_Y, -1.2);

    this.dice.rollTo(
      targetResult,
      targetPos,
      (res) => {
        this.callbacks.onDiceRollComplete?.(res);
        onComplete?.(res);
      },
      () => this.callbacks.onDiceBounce?.()
    );
  }

  private tick() {
    if (this.isDisposed) return;

    const delta = Math.min(this.clock.getDelta(), 0.05);
    const elapsed = this.clock.getElapsedTime();

    // 1. Smooth Camera Damping (Exponential)
    const dampRate = 6.0;
    this.currentCameraPos.x = THREE.MathUtils.damp(
      this.currentCameraPos.x,
      this.targetCameraPos.x,
      dampRate,
      delta
    );
    this.currentCameraPos.y = THREE.MathUtils.damp(
      this.currentCameraPos.y,
      this.targetCameraPos.y,
      dampRate,
      delta
    );
    this.currentCameraPos.z = THREE.MathUtils.damp(
      this.currentCameraPos.z,
      this.targetCameraPos.z,
      dampRate,
      delta
    );

    this.currentLookAt.x = THREE.MathUtils.damp(
      this.currentLookAt.x,
      this.targetLookAt.x,
      dampRate,
      delta
    );
    this.currentLookAt.y = THREE.MathUtils.damp(
      this.currentLookAt.y,
      this.targetLookAt.y,
      dampRate,
      delta
    );
    this.currentLookAt.z = THREE.MathUtils.damp(
      this.currentLookAt.z,
      this.targetLookAt.z,
      dampRate,
      delta
    );

    this.camera.position.copy(this.currentCameraPos);

    // Apply Camera Screen Shake
    if (this.screenShakeIntensity > 0) {
      this.screenShakeIntensity = Math.max(0, this.screenShakeIntensity - delta * 2.2);
      this.camera.position.x += (Math.random() - 0.5) * this.screenShakeIntensity;
      this.camera.position.y += (Math.random() - 0.5) * this.screenShakeIntensity * 0.7;
    }

    this.camera.lookAt(this.currentLookAt);

    // 2. Update Board Details (rotating centerpiece)
    this.board.update(delta, elapsed);

    // 3. Update Visual Effects (particles, shockwaves, markers)
    this.effects.update(delta, elapsed);

    // 4. Update Tokens
    (['red', 'green', 'yellow', 'blue'] as PlayerColor[]).forEach((col) => {
      this.tokens[col].forEach((tok) => tok.update(delta, elapsed));
    });

    // 5. Update Dice
    this.dice.update(delta);

    // 6. Render
    this.renderer.render(this.scene, this.camera);

    // 7. Schedule Next Frame with Software WebGL pacing guard
    if (this.isSoftwareGl) {
      this.afterDraw(() => {
        if (!this.isDisposed) this.tick();
      });
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.isDisposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 6);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 60);
      }
    };
    this.frameId = window.setTimeout(poll, 6);
  }

  public dispose() {
    this.isDisposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    this.board.dispose();
    this.dice.dispose();
    this.effects.dispose();

    (['red', 'green', 'yellow', 'blue'] as PlayerColor[]).forEach((col) => {
      this.tokens[col].forEach((tok) => tok.dispose());
    });

    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
