/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { PlayerColor } from '../game/types';
import {
  COMMON_TRACK_COORDS,
  SAFE_TRACK_INDICES,
  STAR_TRACK_INDICES,
  COLOR_START_TRACK_INDEX,
  COLOR_HOME_LANES,
  YARD_NEST_COORDS,
} from '../game/BoardCoordinates';

export const PLAYER_HEX_COLORS: Record<PlayerColor, string> = {
  red: '#e53935',
  green: '#43a047',
  yellow: '#fbc02d',
  blue: '#1e88e5',
};

export const PLAYER_HEX_NUMBERS: Record<PlayerColor, number> = {
  red: 0xe53935,
  green: 0x43a047,
  yellow: 0xfbc02d,
  blue: 0x1e88e5,
};

/**
 * Generates high-res 2048x2048 procedural canvas texture for the 15x15 Ludo board.
 */
export function createLudoBoardTexture(): THREE.CanvasTexture {
  const size = 2048;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const cellSize = size / 15;

  // Background - rich antique ivory / warm parchment
  ctx.fillStyle = '#faf8f5';
  ctx.fillRect(0, 0, size, size);

  // Subtle parchment texture noise
  for (let i = 0; i < 6000; i++) {
    const rx = Math.random() * size;
    const ry = Math.random() * size;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(0,0,0,0.015)' : 'rgba(255,255,255,0.025)';
    ctx.fillRect(rx, ry, Math.random() * 3 + 1, Math.random() * 3 + 1);
  }

  // Draw Quadrants (Home Yards): 6x6 cells each
  const drawYard = (
    startX: number,
    startY: number,
    colorKey: PlayerColor,
    accentColor: string,
    lightColor: string
  ) => {
    const qX = startX * cellSize;
    const qY = startY * cellSize;
    const qW = 6 * cellSize;
    const qH = 6 * cellSize;

    // Outer colored zone
    ctx.fillStyle = accentColor;
    ctx.fillRect(qX, qY, qW, qH);

    // Inner rounded container
    const pad = cellSize * 0.75;
    const innerX = qX + pad;
    const innerY = qY + pad;
    const innerW = qW - pad * 2;
    const innerH = qH - pad * 2;

    ctx.save();
    ctx.fillStyle = lightColor;
    ctx.shadowColor = 'rgba(0,0,0,0.2)';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.roundRect(innerX, innerY, innerW, innerH, 24);
    ctx.fill();
    ctx.restore();

    // Subtle inner border
    ctx.strokeStyle = 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 3;
    ctx.stroke();

    // 4 Token Yard Circles
    const nests = YARD_NEST_COORDS[colorKey];
    for (const nest of nests) {
      const cx = (nest.x + 0.5) * cellSize;
      const cy = (nest.y + 0.5) * cellSize;
      const radius = cellSize * 0.5;

      // Outer bezel ring
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = accentColor;
      ctx.lineWidth = 6;
      ctx.stroke();

      // Inner color circle
      ctx.fillStyle = accentColor;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 0.65, 0, Math.PI * 2);
      ctx.fill();

      // Subtle metallic highlight
      ctx.fillStyle = 'rgba(255,255,255,0.45)';
      ctx.beginPath();
      ctx.arc(cx - radius * 0.2, cy - radius * 0.2, radius * 0.22, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  // 4 Quadrants
  drawYard(0, 0, 'green', '#2e7d32', '#e8f5e9'); // Top-Left: Green
  drawYard(9, 0, 'yellow', '#f9a825', '#fffde7'); // Top-Right: Yellow
  drawYard(9, 9, 'blue', '#1565c0', '#e3f2fd'); // Bottom-Right: Blue
  drawYard(0, 9, 'red', '#c62828', '#ffebee'); // Bottom-Left: Red

  // Draw Grid Lines across the central cross (cells in range x:6..8 or y:6..8)
  ctx.strokeStyle = '#b0bec5';
  ctx.lineWidth = 2;
  for (let i = 0; i <= 15; i++) {
    // Vertical lines in middle cross
    if (i >= 6 && i <= 9) {
      ctx.beginPath();
      ctx.moveTo(i * cellSize, 0);
      ctx.lineTo(i * cellSize, size);
      ctx.stroke();
    }
    // Horizontal lines in middle cross
    if (i >= 6 && i <= 9) {
      ctx.beginPath();
      ctx.moveTo(0, i * cellSize);
      ctx.lineTo(size, i * cellSize);
      ctx.stroke();
    }
  }

  // Draw Home Columns (5 colored cells each)
  const drawHomeLane = (coords: { x: number; y: number }[], color: string) => {
    ctx.fillStyle = color;
    for (let i = 0; i < 5; i++) {
      const c = coords[i];
      ctx.fillRect(c.x * cellSize + 2, c.y * cellSize + 2, cellSize - 4, cellSize - 4);
    }
  };

  drawHomeLane(COLOR_HOME_LANES.green, '#43a047');
  drawHomeLane(COLOR_HOME_LANES.yellow, '#fbc02d');
  drawHomeLane(COLOR_HOME_LANES.blue, '#1e88e5');
  drawHomeLane(COLOR_HOME_LANES.red, '#e53935');

  // Draw Starting Squares (colored with arrows)
  const drawStartSquare = (colorKey: PlayerColor, color: string) => {
    const idx = COLOR_START_TRACK_INDEX[colorKey];
    const c = COMMON_TRACK_COORDS[idx];
    ctx.fillStyle = color;
    ctx.fillRect(c.x * cellSize + 2, c.y * cellSize + 2, cellSize - 4, cellSize - 4);

    // Star inside starting square
    drawStar(
      ctx,
      (c.x + 0.5) * cellSize,
      (c.y + 0.5) * cellSize,
      5,
      cellSize * 0.35,
      cellSize * 0.16,
      '#ffffff'
    );
  };

  drawStartSquare('red', '#c62828');
  drawStartSquare('blue', '#1565c0');
  drawStartSquare('yellow', '#f9a825');
  drawStartSquare('green', '#2e7d32');

  // Draw Safe Stars on track
  for (let trackIdx = 0; trackIdx < 52; trackIdx++) {
    if (STAR_TRACK_INDICES.has(trackIdx)) {
      const c = COMMON_TRACK_COORDS[trackIdx];
      drawStar(
        ctx,
        (c.x + 0.5) * cellSize,
        (c.y + 0.5) * cellSize,
        5,
        cellSize * 0.36,
        cellSize * 0.16,
        '#78909c'
      );
    }
  }

  // Draw Center Finish Zone (4 Triangles meeting at 7.5, 7.5)
  const cx = 7.5 * cellSize;
  const cy = 7.5 * cellSize;
  const leftX = 6 * cellSize;
  const rightX = 9 * cellSize;
  const topY = 6 * cellSize;
  const botY = 9 * cellSize;

  // Top Triangle (Green)
  ctx.fillStyle = '#2e7d32';
  ctx.beginPath();
  ctx.moveTo(leftX, topY);
  ctx.lineTo(rightX, topY);
  ctx.lineTo(cx, cy);
  ctx.closePath();
  ctx.fill();

  // Right Triangle (Yellow)
  ctx.fillStyle = '#f9a825';
  ctx.beginPath();
  ctx.moveTo(rightX, topY);
  ctx.lineTo(rightX, botY);
  ctx.lineTo(cx, cy);
  ctx.closePath();
  ctx.fill();

  // Bottom Triangle (Blue)
  ctx.fillStyle = '#1565c0';
  ctx.beginPath();
  ctx.moveTo(rightX, botY);
  ctx.lineTo(leftX, botY);
  ctx.lineTo(cx, cy);
  ctx.closePath();
  ctx.fill();

  // Left Triangle (Red)
  ctx.fillStyle = '#c62828';
  ctx.beginPath();
  ctx.moveTo(leftX, botY);
  ctx.lineTo(leftX, topY);
  ctx.lineTo(cx, cy);
  ctx.closePath();
  ctx.fill();

  // Center golden medallion / star
  ctx.fillStyle = '#ffd54f';
  ctx.beginPath();
  ctx.arc(cx, cy, cellSize * 0.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#b78103';
  ctx.lineWidth = 4;
  ctx.stroke();

  drawStar(ctx, cx, cy, 8, cellSize * 0.42, cellSize * 0.22, '#fff8e1');

  // Outer border around the whole 15x15 board
  ctx.strokeStyle = '#455a64';
  ctx.lineWidth = 8;
  ctx.strokeRect(4, 4, size - 8, size - 8);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.generateMipmaps = true;
  return texture;
}

/** Helper to draw a crisp geometric star */
function drawStar(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  spikes: number,
  outerRadius: number,
  innerRadius: number,
  fillColor: string
) {
  let rot = (Math.PI / 2) * 3;
  let x = cx;
  let y = cy;
  const step = Math.PI / spikes;

  ctx.beginPath();
  ctx.moveTo(cx, cy - outerRadius);
  for (let i = 0; i < spikes; i++) {
    x = cx + Math.cos(rot) * outerRadius;
    y = cy + Math.sin(rot) * outerRadius;
    ctx.lineTo(x, y);
    rot += step;

    x = cx + Math.cos(rot) * innerRadius;
    y = cy + Math.sin(rot) * innerRadius;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.lineTo(cx, cy - outerRadius);
  ctx.closePath();
  ctx.fillStyle = fillColor;
  ctx.fill();
}

/**
 * Creates high-fidelity procedural rich walnut wood grain texture for the table.
 */
export function createWoodTableTexture(): THREE.CanvasTexture {
  const width = 1024;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Base warm walnut wood tone
  const grad = ctx.createLinearGradient(0, 0, width, height);
  grad.addColorStop(0, '#2d1b10');
  grad.addColorStop(0.5, '#3e271a');
  grad.addColorStop(1, '#25150d');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Subtle wood planks / grain lines
  ctx.fillStyle = 'rgba(0, 0, 0, 0.04)';
  for (let y = 0; y < height; y += 4) {
    const wave = Math.sin(y * 0.05) * 8;
    ctx.fillRect(0, y + wave, width, 2);
  }

  // Soft wood rings
  ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
  for (let i = 0; i < 40; i++) {
    const cy = Math.random() * height;
    ctx.beginPath();
    ctx.ellipse(width / 2, cy, width * 0.8, 12 + Math.random() * 20, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 4);
  return texture;
}

/**
 * Creates a soft radial contact shadow texture for tokens and dice.
 */
export function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
  grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.25)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}
