/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { PlayerColor } from '../game/types';
import { PLAYER_HEX_NUMBERS } from './Materials';
import { getTokenWorldPosition, BOARD_SURFACE_Y } from '../game/BoardCoordinates';
import { createContactShadowTexture } from './Materials';

export class Token3D {
  public group: THREE.Group;
  public color: PlayerColor;
  public id: number;

  // Visual sub-meshes
  public headMesh: THREE.Mesh;
  private selectionRing: THREE.Mesh;
  private shadowMesh: THREE.Mesh;
  private crownRingMesh: THREE.Mesh;

  // State
  public isSelectable = false;
  public isSelected = false;
  public isAnimating = false;

  // Animation interpolation state
  private animationQueue: {
    startPos: THREE.Vector3;
    endPos: THREE.Vector3;
    progress: number;
    duration: number;
    hopHeight: number;
    isKillKnockout?: boolean;
    isStompSlam?: boolean;
    onComplete?: () => void;
  }[] = [];

  constructor(color: PlayerColor, id: number) {
    this.color = color;
    this.id = id;

    this.group = new THREE.Group();
    this.group.name = `Token_${color}_${id}`;
    this.group.userData = { color, id, isToken: true };

    const hexColor = PLAYER_HEX_NUMBERS[color];

    // 1. Shared Materials
    const baseMetalMat = new THREE.MeshStandardMaterial({
      color: 0xdcdcdc,
      metalness: 0.9,
      roughness: 0.2,
    });

    const goldAccentMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      metalness: 0.92,
      roughness: 0.16,
      emissive: 0x996515,
      emissiveIntensity: 0.15,
    });

    const lacquerColorMat = new THREE.MeshStandardMaterial({
      color: hexColor,
      roughness: 0.12,
      metalness: 0.12,
    });

    // 2. Part 1: Weighted Brass Base Ring with beveled chamfer
    const baseGeo = new THREE.CylinderGeometry(0.24, 0.27, 0.08, 24);
    const baseMesh = new THREE.Mesh(baseGeo, baseMetalMat);
    baseMesh.position.y = 0.04;
    baseMesh.castShadow = true;
    baseMesh.receiveShadow = true;
    baseMesh.userData = this.group.userData;
    this.group.add(baseMesh);

    // 3. Part 2: Lower Felt Ring
    const feltMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
    const feltGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.015, 24);
    const feltMesh = new THREE.Mesh(feltGeo, feltMat);
    feltMesh.position.y = 0.008;
    this.group.add(feltMesh);

    // 4. Part 3: Flared Middle Stem
    const stemGeo = new THREE.CylinderGeometry(0.12, 0.22, 0.32, 24);
    const stemMesh = new THREE.Mesh(stemGeo, lacquerColorMat);
    stemMesh.position.y = 0.22;
    stemMesh.castShadow = true;
    stemMesh.userData = this.group.userData;
    this.group.add(stemMesh);

    // 5. Part 4: Gold Collar Accent Ring
    const collarGeo = new THREE.TorusGeometry(0.14, 0.03, 12, 24);
    const collarMesh = new THREE.Mesh(collarGeo, goldAccentMat);
    collarMesh.rotation.x = Math.PI / 2;
    collarMesh.position.y = 0.38;
    collarMesh.castShadow = true;
    collarMesh.userData = this.group.userData;
    this.group.add(collarMesh);

    // 6. Part 5: Spherical Head Dome
    const headGeo = new THREE.SphereGeometry(0.18, 24, 20);
    this.headMesh = new THREE.Mesh(headGeo, lacquerColorMat);
    this.headMesh.position.y = 0.52;
    this.headMesh.castShadow = true;
    this.headMesh.userData = this.group.userData;
    this.group.add(this.headMesh);

    // 7. Part 6: Top Finial Crest / Royal Crown Ring
    const crestGeo = new THREE.CylinderGeometry(0.02, 0.045, 0.07, 12);
    const crestMesh = new THREE.Mesh(crestGeo, goldAccentMat);
    crestMesh.position.y = 0.72;
    crestMesh.castShadow = true;
    crestMesh.userData = this.group.userData;
    this.group.add(crestMesh);

    const crownGeo = new THREE.TorusGeometry(0.065, 0.016, 8, 16);
    this.crownRingMesh = new THREE.Mesh(crownGeo, goldAccentMat);
    this.crownRingMesh.rotation.x = Math.PI / 2;
    this.crownRingMesh.position.y = 0.69;
    this.group.add(this.crownRingMesh);

    // 8. Contact Shadow Disk
    const shadowTex = createContactShadowTexture();
    const shadowGeo = new THREE.PlaneGeometry(0.68, 0.68);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
    });
    this.shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    this.shadowMesh.rotation.x = -Math.PI / 2;
    this.shadowMesh.position.y = 0.005;
    this.group.add(this.shadowMesh);

    // 9. Interactive Selection / Pulsing Ring
    const ringGeo = new THREE.RingGeometry(0.28, 0.38, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    this.selectionRing = new THREE.Mesh(ringGeo, ringMat);
    this.selectionRing.rotation.x = -Math.PI / 2;
    this.selectionRing.position.y = 0.012;
    this.group.add(this.selectionRing);

    // Initial position in yard
    const initWorld = getTokenWorldPosition(color, id, -1);
    this.group.position.set(initWorld.x, initWorld.y, initWorld.z);
  }

  public setSelectable(selectable: boolean) {
    this.isSelectable = selectable;
    if (selectable) {
      (this.selectionRing.material as THREE.MeshBasicMaterial).opacity = 0.85;
      (this.selectionRing.material as THREE.MeshBasicMaterial).color.setHex(0xffffff);
    } else if (!this.isSelected) {
      (this.selectionRing.material as THREE.MeshBasicMaterial).opacity = 0;
    }
  }

  public setSelected(selected: boolean) {
    this.isSelected = selected;
    if (selected) {
      (this.selectionRing.material as THREE.MeshBasicMaterial).opacity = 1.0;
      (this.selectionRing.material as THREE.MeshBasicMaterial).color.setHex(0xffeb3b);
    } else if (!this.isSelectable) {
      (this.selectionRing.material as THREE.MeshBasicMaterial).opacity = 0;
    }
  }

  /**
   * Snaps token directly to a given step's world position.
   */
  public snapToStep(stepIndex: number) {
    this.animationQueue = [];
    this.isAnimating = false;
    this.group.rotation.set(0, 0, 0);
    const w = getTokenWorldPosition(this.color, this.id, stepIndex);
    this.group.position.set(w.x, w.y, w.z);
  }

  /**
   * Enqueues smooth hop animation along intermediate steps.
   */
  public animatePath(
    stepPath: number[],
    speedMultiplier = 1,
    onStepHop?: (step: number) => void,
    onComplete?: () => void
  ) {
    this.animationQueue = [];
    this.isAnimating = true;

    for (let i = 0; i < stepPath.length; i++) {
      const step = stepPath[i];
      const targetPos = getTokenWorldPosition(this.color, this.id, step);
      const isLast = i === stepPath.length - 1;

      const duration = 0.15 / speedMultiplier;

      this.animationQueue.push({
        startPos: new THREE.Vector3(),
        endPos: new THREE.Vector3(targetPos.x, targetPos.y, targetPos.z),
        progress: 0,
        duration,
        hopHeight: 0.35,
        onComplete: () => {
          if (onStepHop) onStepHop(step);
          if (isLast && onComplete) onComplete();
        },
      });
    }
  }

  /**
   * Attacking slam stomp on a captured square.
   */
  public animateStomp(onComplete?: () => void) {
    const curPos = this.group.position.clone();
    this.animationQueue.push({
      startPos: curPos,
      endPos: curPos.clone(),
      progress: 0,
      duration: 0.22,
      hopHeight: 0.65,
      isStompSlam: true,
      onComplete,
    });
  }

  /**
   * Dramatic "Kill / Knockout" tumbling flight back to home yard:
   * 1. High explosive launch arc (2.6 units high).
   * 2. Wild multi-axis tumbling spin in mid-air.
   * 3. Hard impact in yard with bounce and upright settling!
   */
  public animateKillKnockout(onYardLand?: () => void, onComplete?: () => void) {
    this.animationQueue = [];
    this.isAnimating = true;

    const targetPos = getTokenWorldPosition(this.color, this.id, -1);

    this.animationQueue.push({
      startPos: this.group.position.clone(),
      endPos: new THREE.Vector3(targetPos.x, targetPos.y, targetPos.z),
      progress: 0,
      duration: 0.75,
      hopHeight: 2.6, // dramatic high arc across the board
      isKillKnockout: true,
      onComplete: () => {
        onYardLand?.();
        // Secondary yard bounce
        this.animationQueue.push({
          startPos: new THREE.Vector3(targetPos.x, targetPos.y, targetPos.z),
          endPos: new THREE.Vector3(targetPos.x, targetPos.y, targetPos.z),
          progress: 0,
          duration: 0.22,
          hopHeight: 0.3,
          onComplete: () => {
            this.group.rotation.set(0, 0, 0);
            this.isAnimating = false;
            onComplete?.();
          },
        });
      },
    });
  }

  /**
   * Per-frame update for hops, tumbling knockouts, idle floating, and ring pulsing.
   */
  public update(delta: number, elapsed: number) {
    if (this.animationQueue.length > 0) {
      const currentHop = this.animationQueue[0];

      if (currentHop.progress === 0) {
        currentHop.startPos.copy(this.group.position);
      }

      currentHop.progress += delta / currentHop.duration;

      if (currentHop.progress >= 1.0) {
        currentHop.progress = 1.0;
        this.group.position.copy(currentHop.endPos);
        if (currentHop.isKillKnockout) {
          this.group.rotation.set(0, 0, 0);
        }
        currentHop.onComplete?.();
        this.animationQueue.shift();

        if (this.animationQueue.length === 0) {
          this.isAnimating = false;
        }
      } else {
        const t = currentHop.progress;

        // Position interpolation
        this.group.position.x = THREE.MathUtils.lerp(currentHop.startPos.x, currentHop.endPos.x, t);
        this.group.position.z = THREE.MathUtils.lerp(currentHop.startPos.z, currentHop.endPos.z, t);

        // Arc on Y
        const arcY = Math.sin(t * Math.PI) * currentHop.hopHeight;
        this.group.position.y = BOARD_SURFACE_Y + arcY;

        // Knockout tumbling in mid-air
        if (currentHop.isKillKnockout) {
          const tumble = t * Math.PI * 4;
          this.group.rotation.x = Math.sin(tumble) * 1.5;
          this.group.rotation.z = Math.cos(tumble) * 1.5;
          this.group.rotation.y += delta * 12;
        } else {
          this.group.rotation.set(0, 0, 0);
        }

        // Contact shadow scale
        const shadowScale = Math.max(0.15, 1.0 - arcY * 0.35);
        this.shadowMesh.scale.set(shadowScale, shadowScale, shadowScale);
      }
    } else {
      // Idle animations
      this.group.rotation.set(0, 0, 0);

      if (this.isSelectable || this.isSelected) {
        // Gentle bobbing bounce
        const bob = Math.sin(elapsed * 4.5 + this.id) * 0.045;
        this.group.position.y = BOARD_SURFACE_Y + Math.max(0, bob);

        // Ring pulse
        const pulse = 1.0 + Math.sin(elapsed * 6) * 0.09;
        this.selectionRing.scale.set(pulse, pulse, pulse);
      } else {
        this.group.position.y = BOARD_SURFACE_Y;
        this.selectionRing.scale.set(1, 1, 1);
        this.shadowMesh.scale.set(1, 1, 1);
      }
    }
  }

  public dispose() {
    this.group.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.geometry.dispose();
        if (Array.isArray(child.material)) {
          child.material.forEach((m) => m.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
  }
}
